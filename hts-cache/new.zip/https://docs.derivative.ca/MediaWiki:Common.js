<!DOCTYPE html>
<html class="client-nojs" lang="en-CA" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>MediaWiki:common.js - Derivative</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":false,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"9c7556ff5a30882fcd5ba378","wgCSPNonce":false,"wgCanonicalNamespace":"MediaWiki","wgCanonicalSpecialPageName":false,"wgNamespaceNumber":8,"wgPageName":"MediaWiki:Common.js","wgTitle":"Common.js","wgCurRevisionId":28654,"wgRevisionId":28654,"wgArticleId":1013,"wgIsArticle":true,"wgIsRedirect":false,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":["COMPs"],"wgPageContentLanguage":"en","wgPageContentModel":"javascript","wgRelevantPageName":"MediaWiki:Common.js","wgRelevantArticleId":1013,"wgIsProbablyEditable":false,"wgRelevantPageIsProbablyEditable":false,"wgRestrictionEdit":[],"wgRestrictionMove":[],"wgCargoDefaultQueryLimit":100,
"wgCargoMapClusteringMinimum":80,"wgCargoMonthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"wgCargoMonthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"wgCargoWeekDays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"wgCargoWeekDaysShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"wgPageFormsTargetName":null,"wgPageFormsAutocompleteValues":[],"wgPageFormsAutocompleteOnAllChars":false,"wgPageFormsFieldProperties":[],"wgPageFormsCargoFields":[],"wgPageFormsDependentFields":[],"wgPageFormsCalendarValues":[],"wgPageFormsCalendarParams":[],"wgPageFormsCalendarHTML":null,"wgPageFormsGridValues":[],"wgPageFormsGridParams":[],"wgPageFormsContLangYes":null,"wgPageFormsContLangNo":null,"wgPageFormsContLangMonths":[],"wgPageFormsHeightForMinimizingInstances":800,"wgPageFormsShowOnSelect":[],"wgPageFormsScriptPath":"/extensions/PageForms","edgValues":{"title"
:["Add SOP","Alembic SOP","Align SOP","Arm SOP","Attribute Create SOP","Attribute SOP","Basis SOP","Blend SOP","Bone Group SOP","Boolean SOP","Box SOP","Bridge SOP","Cache SOP","Cap SOP","Capture Region SOP","Capture SOP","Carve SOP","CHOP to SOP","Circle SOP","Clay SOP","Clip SOP","Convert SOP","Copy SOP","CPlusPlus SOP","Creep SOP","Curveclay SOP","Curvesect SOP","DAT to SOP","Deform SOP","Delete SOP","Divide SOP","Extrude SOP","Face Track SOP","Facet SOP","File In SOP","Fillet SOP","Fit SOP","Font SOP","Force SOP","Fractal SOP","Grid SOP","Group SOP","Hole SOP","Import Select SOP","In SOP","Introduction To SOPs Vid","Inverse Curve SOP","Iso Surface SOP","Join SOP","Joint SOP","Kinect SOP","Lattice SOP","Limit SOP","Line SOP","Line Thick SOP","LOD SOP","LSystem SOP","Magnet SOP","Material SOP","Merge SOP","Metaball SOP","Model SOP","Noise SOP","Null SOP","Object Merge SOP","Oculus Rift SOP","OpenVR SOP","Out SOP","Particle SOP","Point SOP","Polyloft SOP","Polypatch SOP",
"Polyreduce SOP","Polyspline SOP","Polystitch SOP","Primitive SOP","Profile SOP","Project SOP","Rails SOP","Raster SOP","Ray SOP","Rectangle SOP","Refine SOP","Resample SOP","Revolve SOP","Script SOP","Select SOP","Sequence Blend SOP","Skin SOP","Sort SOP","Sphere SOP","Spring SOP","Sprinkle SOP","Sprite SOP","Stitch SOP","Subdivide SOP","Superquad SOP","Surfsect SOP","Sweep SOP","Switch SOP","Text SOP","Texture SOP","Torus SOP","Trace SOP","Trail SOP","Transform SOP","Trim SOP","Tristrip SOP","Tube SOP","Twist SOP","Vertex SOP","Wireframe SOP","ZED SOP","Experimental:ZED SOP"]},"wgPageFormsEDSettings":null,"wgAmericanDates":false,"wgVector2022PreviewPages":[]};RLSTATE={"site.styles":"ready","user.styles":"ready","user":"ready","user.options":"loading","mediawiki.action.styles":"ready","ext.pygments":"ready","ext.Lingo.styles":"ready","skins.vector.styles.legacy":"ready"};RLPAGEMODULES=["ext.UiTag","ext.pygments.linenumbers","ext.Lingo","site","mediawiki.page.ready",
"skins.vector.legacy.js"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@12s5i",function($,jQuery,require,module){mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});});});</script>
<link rel="stylesheet" href="/load.php?lang=en-ca&amp;modules=ext.Lingo.styles%7Cext.pygments%7Cmediawiki.action.styles%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/load.php?lang=en-ca&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/load.php?lang=en-ca&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.39.0"/>
<meta name="format-detection" content="telephone=no"/>
<meta name="twitter:card" content="summary_large_image"/>
<meta name="viewport" content="width=1000"/>
<link rel="icon" href="/favicon.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/opensearch_desc.php" title="Derivative (en-ca)"/>
<link rel="EditURI" type="application/rsd+xml" href="https://docs.derivative.ca/api.php?action=rsd"/>
<link rel="alternate" type="application/atom+xml" title="Derivative Atom feed" href="/index.php?title=Special:RecentChanges&amp;feed=atom"/>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-3123499-6"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-3123499-6');
</script>
<meta property="og:title" content="MediaWiki:Common.js"/>
<meta property="og:site_name" content="Derivative"/>
<meta property="og:url" content="https://docs.derivative.ca/MediaWiki:Common.js"/>
<meta property="og:image" content="https://docs.derivative.ca/resources/assets/logo.png"/>
<meta property="article:modified_time" content="2023-04-06T16:23:33Z"/>
<meta property="article:published_time" content="2023-04-06T16:23:33Z"/>
<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"Article","name":"MediaWiki:common.js - Derivative","headline":"MediaWiki:common.js - Derivative","mainEntityOfPage":"MediaWiki:common.js","identifier":"https:\/\/docs.derivative.ca\/MediaWiki:Common.js","url":"https:\/\/docs.derivative.ca\/MediaWiki:Common.js","dateModified":"2023-04-06T16:23:33Z","datePublished":"2023-04-06T16:23:33Z","image":{"@type":"ImageObject","url":"https:\/\/docs.derivative.ca\/resources\/assets\/logo.png"},"author":{"@type":"Organization","name":"Derivative","url":"https:\/\/docs.derivative.ca","logo":{"@type":"ImageObject","url":"https:\/\/docs.derivative.ca\/resources\/assets\/logo.png","caption":"Derivative"}},"publisher":{"@type":"Organization","name":"Derivative","url":"https:\/\/docs.derivative.ca","logo":{"@type":"ImageObject","url":"https:\/\/docs.derivative.ca\/resources\/assets\/logo.png","caption":"Derivative"}},"potentialAction":{"@type":"SearchAction","target":"https:\/\/docs.derivative.ca\/index.php?title=Special:Search&search={search_term}","query-input":"required name=search_term"}}</script>
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-8 ns-subject page-MediaWiki_Common_js rootpage-MediaWiki_Common_js skin-vector action-view skin-vector-legacy vector-feature-language-in-header-enabled vector-feature-language-in-main-page-header-disabled vector-feature-language-alert-in-sidebar-disabled vector-feature-sticky-header-disabled vector-feature-sticky-header-edit-disabled vector-feature-table-of-contents-disabled vector-feature-visual-enhancement-next-disabled"><div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice"></div>
	<div class="mw-indicators">
	</div>
	<h1 id="firstHeading" class="firstHeading mw-first-heading">MediaWiki:common.js</h1>
	<div id="bodyContent" class="vector-body">
		<div id="siteSub" class="noprint">From Derivative</div>
		<div id="contentSub"></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" class="mw-body-content mw-content-ltr" lang="en" dir="ltr"><div id="mw-clearyourcache" lang="en-CA" dir="ltr" class="mw-content-ltr">
<p><strong>Note:</strong> After publishing, you may have to bypass your browser's cache to see the changes.
</p>
<ul><li><strong>Firefox / Safari:</strong> Hold <em>Shift</em> while clicking <em>Reload</em>, or press either <em>Ctrl-F5</em> or <em>Ctrl-R</em> (<em>⌘-R</em> on a Mac)</li>
<li><strong>Google Chrome:</strong> Press <em>Ctrl-Shift-R</em> (<em>⌘-Shift-R</em> on a Mac)</li>
<li><strong>Internet Explorer / Edge:</strong> Hold <em>Ctrl</em> while clicking <em>Refresh</em>, or press <em>Ctrl-F5</em></li>
<li><strong>Opera:</strong> Press <em>Ctrl-F5</em>.</li></ul>
</div><div class="mw-parser-output"><div class="mw-parser-output"><div class="mw-highlight mw-highlight-lang-javascript mw-content-ltr mw-highlight-lines" dir="ltr"><pre><span></span><span id="L-1"><a href="#L-1"><span class="linenos" data-line="1"></span></a><span class="cm">/* Any JavaScript here will be loaded for all users on every page load. */</span>
</span><span id="L-2"><a href="#L-2"><span class="linenos" data-line="2"></span></a>
</span><span id="L-3"><a href="#L-3"><span class="linenos" data-line="3"></span></a><span class="kd">function</span> <span class="nx">findGetParameter</span><span class="p">(</span><span class="nx">parameterName</span><span class="p">)</span> <span class="p">{</span>
</span><span id="L-4"><a href="#L-4"><span class="linenos" data-line="4"></span></a>    <span class="kd">var</span> <span class="nx">result</span> <span class="o">=</span> <span class="kc">null</span><span class="p">,</span>
</span><span id="L-5"><a href="#L-5"><span class="linenos" data-line="5"></span></a>        <span class="nx">tmp</span> <span class="o">=</span> <span class="p">[];</span>
</span><span id="L-6"><a href="#L-6"><span class="linenos" data-line="6"></span></a>    <span class="nx">location</span><span class="p">.</span><span class="nx">search</span>
</span><span id="L-7"><a href="#L-7"><span class="linenos" data-line="7"></span></a>        <span class="p">.</span><span class="nx">substr</span><span class="p">(</span><span class="mf">1</span><span class="p">)</span>
</span><span id="L-8"><a href="#L-8"><span class="linenos" data-line="8"></span></a>        <span class="p">.</span><span class="nx">split</span><span class="p">(</span><span class="s2">"&amp;"</span><span class="p">)</span>
</span><span id="L-9"><a href="#L-9"><span class="linenos" data-line="9"></span></a>        <span class="p">.</span><span class="nx">forEach</span><span class="p">(</span><span class="kd">function</span> <span class="p">(</span><span class="nx">item</span><span class="p">)</span> <span class="p">{</span>
</span><span id="L-10"><a href="#L-10"><span class="linenos" data-line="10"></span></a>          <span class="nx">tmp</span> <span class="o">=</span> <span class="nx">item</span><span class="p">.</span><span class="nx">split</span><span class="p">(</span><span class="s2">"="</span><span class="p">);</span>
</span><span id="L-11"><a href="#L-11"><span class="linenos" data-line="11"></span></a>          <span class="k">if</span> <span class="p">(</span><span class="nx">tmp</span><span class="p">[</span><span class="mf">0</span><span class="p">]</span> <span class="o">===</span> <span class="nx">parameterName</span><span class="p">)</span> <span class="nx">result</span> <span class="o">=</span> <span class="nb">decodeURIComponent</span><span class="p">(</span><span class="nx">tmp</span><span class="p">[</span><span class="mf">1</span><span class="p">]);</span>
</span><span id="L-12"><a href="#L-12"><span class="linenos" data-line="12"></span></a>        <span class="p">});</span>
</span><span id="L-13"><a href="#L-13"><span class="linenos" data-line="13"></span></a>    <span class="k">return</span> <span class="nx">result</span><span class="p">;</span>
</span><span id="L-14"><a href="#L-14"><span class="linenos" data-line="14"></span></a><span class="p">}</span>
</span><span id="L-15"><a href="#L-15"><span class="linenos" data-line="15"></span></a>
</span><span id="L-16"><a href="#L-16"><span class="linenos" data-line="16"></span></a><span class="cm">/* load TOC collapsed */</span>
</span><span id="L-17"><a href="#L-17"><span class="linenos" data-line="17"></span></a><span class="nb">window</span><span class="p">.</span><span class="nx">addEventListener</span><span class="p">(</span><span class="s1">'DOMContentLoaded'</span><span class="p">,</span> <span class="kd">function</span><span class="p">()</span> <span class="p">{</span> <span class="k">try</span> <span class="p">{</span>
</span><span id="L-18"><a href="#L-18"><span class="linenos" data-line="18"></span></a>  <span class="k">if</span> <span class="p">(</span><span class="nb">document</span><span class="p">.</span><span class="nx">getElementById</span><span class="p">(</span><span class="s1">'toc'</span><span class="p">).</span><span class="nx">getElementsByTagName</span><span class="p">(</span><span class="s1">'ul'</span><span class="p">)[</span><span class="mf">0</span><span class="p">].</span><span class="nx">style</span><span class="p">.</span><span class="nx">display</span> <span class="o">!=</span> <span class="s1">'none'</span><span class="p">)</span> <span class="p">{</span> <span class="nx">toggleToc</span><span class="p">();</span> <span class="p">}</span>
</span><span id="L-19"><a href="#L-19"><span class="linenos" data-line="19"></span></a><span class="p">}</span> <span class="k">catch</span> <span class="p">(</span><span class="nx">exception</span><span class="p">)</span> <span class="p">{}</span> <span class="p">},</span> <span class="kc">false</span><span class="p">);</span>
</span><span id="L-20"><a href="#L-20"><span class="linenos" data-line="20"></span></a>
</span><span id="L-21"><a href="#L-21"><span class="linenos" data-line="21"></span></a><span class="cm">/* custom toolbars */</span>
</span><span id="L-22"><a href="#L-22"><span class="linenos" data-line="22"></span></a><span class="kd">var</span> <span class="nx">customizeToolbar</span> <span class="o">=</span> <span class="kd">function</span> <span class="p">()</span> <span class="p">{</span>
</span><span id="L-23"><a href="#L-23"><span class="linenos" data-line="23"></span></a>	<span class="nx">$</span><span class="p">(</span> <span class="s1">'#wpTextbox1'</span> <span class="p">).</span><span class="nx">wikiEditor</span><span class="p">(</span> <span class="s1">'addToToolbar'</span><span class="p">,</span> <span class="p">{</span>
</span><span id="L-24"><a href="#L-24"><span class="linenos" data-line="24"></span></a>		<span class="s1">'section'</span><span class="o">:</span> <span class="s1">'main'</span><span class="p">,</span>
</span><span id="L-25"><a href="#L-25"><span class="linenos" data-line="25"></span></a>		<span class="s1">'group'</span><span class="o">:</span> <span class="s1">'format'</span><span class="p">,</span>
</span><span id="L-26"><a href="#L-26"><span class="linenos" data-line="26"></span></a>		<span class="s1">'tools'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-27"><a href="#L-27"><span class="linenos" data-line="27"></span></a>			<span class="s2">"TDpythonbutton"</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-28"><a href="#L-28"><span class="linenos" data-line="28"></span></a>				<span class="nx">label</span><span class="o">:</span> <span class="s1">'Python code'</span><span class="p">,</span>
</span><span id="L-29"><a href="#L-29"><span class="linenos" data-line="29"></span></a>				<span class="nx">type</span><span class="o">:</span> <span class="s1">'button'</span><span class="p">,</span>
</span><span id="L-30"><a href="#L-30"><span class="linenos" data-line="30"></span></a>				<span class="nx">icon</span><span class="o">:</span> <span class="s1">'https://docs.derivative.ca/images/b/bf/Pythonbutton.png'</span><span class="p">,</span>
</span><span id="L-31"><a href="#L-31"><span class="linenos" data-line="31"></span></a>				<span class="nx">action</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-32"><a href="#L-32"><span class="linenos" data-line="32"></span></a>					<span class="nx">type</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-33"><a href="#L-33"><span class="linenos" data-line="33"></span></a>					<span class="nx">options</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-34"><a href="#L-34"><span class="linenos" data-line="34"></span></a>						<span class="nx">pre</span><span class="o">:</span> <span class="s2">"&lt;syntaxhighlight lang=python&gt;"</span><span class="p">,</span>
</span><span id="L-35"><a href="#L-35"><span class="linenos" data-line="35"></span></a>						<span class="nx">post</span><span class="o">:</span> <span class="s2">"&lt;/syntaxhighlight&gt;"</span>
</span><span id="L-36"><a href="#L-36"><span class="linenos" data-line="36"></span></a>	  				<span class="p">}</span>
</span><span id="L-37"><a href="#L-37"><span class="linenos" data-line="37"></span></a>	           <span class="p">}</span>
</span><span id="L-38"><a href="#L-38"><span class="linenos" data-line="38"></span></a>			<span class="p">},</span>
</span><span id="L-39"><a href="#L-39"><span class="linenos" data-line="39"></span></a>			<span class="s2">"TDcodebutton"</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-40"><a href="#L-40"><span class="linenos" data-line="40"></span></a>			<span class="nx">label</span><span class="o">:</span> <span class="s1">'Source code'</span><span class="p">,</span>
</span><span id="L-41"><a href="#L-41"><span class="linenos" data-line="41"></span></a>			<span class="nx">type</span><span class="o">:</span> <span class="s1">'button'</span><span class="p">,</span>
</span><span id="L-42"><a href="#L-42"><span class="linenos" data-line="42"></span></a>			<span class="nx">icon</span><span class="o">:</span> <span class="s1">'https://docs.derivative.ca/images/0/05/Codebutton.png'</span><span class="p">,</span>
</span><span id="L-43"><a href="#L-43"><span class="linenos" data-line="43"></span></a>				<span class="nx">action</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-44"><a href="#L-44"><span class="linenos" data-line="44"></span></a>					<span class="nx">type</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-45"><a href="#L-45"><span class="linenos" data-line="45"></span></a>					<span class="nx">options</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-46"><a href="#L-46"><span class="linenos" data-line="46"></span></a>						<span class="nx">pre</span><span class="o">:</span> <span class="s2">"&lt;code&gt;"</span><span class="p">,</span>
</span><span id="L-47"><a href="#L-47"><span class="linenos" data-line="47"></span></a>						<span class="nx">post</span><span class="o">:</span> <span class="s2">"&lt;/code&gt;"</span>
</span><span id="L-48"><a href="#L-48"><span class="linenos" data-line="48"></span></a>	  				<span class="p">}</span>
</span><span id="L-49"><a href="#L-49"><span class="linenos" data-line="49"></span></a>	            <span class="p">}</span>
</span><span id="L-50"><a href="#L-50"><span class="linenos" data-line="50"></span></a>			<span class="p">},</span>
</span><span id="L-51"><a href="#L-51"><span class="linenos" data-line="51"></span></a>			<span class="s2">"TDyoutubebutton"</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-52"><a href="#L-52"><span class="linenos" data-line="52"></span></a>			<span class="nx">label</span><span class="o">:</span> <span class="s1">'Embed YouTube video'</span><span class="p">,</span>
</span><span id="L-53"><a href="#L-53"><span class="linenos" data-line="53"></span></a>			<span class="nx">type</span><span class="o">:</span> <span class="s1">'button'</span><span class="p">,</span>
</span><span id="L-54"><a href="#L-54"><span class="linenos" data-line="54"></span></a>			<span class="nx">icon</span><span class="o">:</span> <span class="s1">'https://docs.derivative.ca/images/a/af/Youtube.png'</span><span class="p">,</span>
</span><span id="L-55"><a href="#L-55"><span class="linenos" data-line="55"></span></a>			<span class="nx">action</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-56"><a href="#L-56"><span class="linenos" data-line="56"></span></a>				<span class="nx">type</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-57"><a href="#L-57"><span class="linenos" data-line="57"></span></a>				<span class="nx">options</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-58"><a href="#L-58"><span class="linenos" data-line="58"></span></a>					<span class="nx">pre</span><span class="o">:</span> <span class="s2">"{{#widget:YouTube|id=|width=|height=}}"</span><span class="p">,</span>
</span><span id="L-59"><a href="#L-59"><span class="linenos" data-line="59"></span></a>					<span class="nx">post</span><span class="o">:</span> <span class="s2">""</span>
</span><span id="L-60"><a href="#L-60"><span class="linenos" data-line="60"></span></a>				<span class="p">}</span>
</span><span id="L-61"><a href="#L-61"><span class="linenos" data-line="61"></span></a>			<span class="p">}</span>
</span><span id="L-62"><a href="#L-62"><span class="linenos" data-line="62"></span></a>			<span class="p">}</span>
</span><span id="L-63"><a href="#L-63"><span class="linenos" data-line="63"></span></a>		<span class="p">}</span>
</span><span id="L-64"><a href="#L-64"><span class="linenos" data-line="64"></span></a>	<span class="p">}</span> <span class="p">);</span>
</span><span id="L-65"><a href="#L-65"><span class="linenos" data-line="65"></span></a>	<span class="nx">$</span><span class="p">(</span> <span class="s1">'#wpTextbox1'</span> <span class="p">).</span><span class="nx">wikiEditor</span><span class="p">(</span> <span class="s1">'addToToolbar'</span><span class="p">,</span> <span class="p">{</span>
</span><span id="L-66"><a href="#L-66"><span class="linenos" data-line="66"></span></a>		<span class="s1">'sections'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-67"><a href="#L-67"><span class="linenos" data-line="67"></span></a>			<span class="s1">'templates'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-68"><a href="#L-68"><span class="linenos" data-line="68"></span></a>				<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'booklet'</span><span class="p">,</span> <span class="c1">// Can also be 'booklet'</span>
</span><span id="L-69"><a href="#L-69"><span class="linenos" data-line="69"></span></a>				<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Templates'</span><span class="p">,</span>
</span><span id="L-70"><a href="#L-70"><span class="linenos" data-line="70"></span></a>				<span class="s1">'pages'</span><span class="o">:</span><span class="p">{</span>
</span><span id="L-71"><a href="#L-71"><span class="linenos" data-line="71"></span></a>					<span class="s1">'section-glossary'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-72"><a href="#L-72"><span class="linenos" data-line="72"></span></a>						<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Glossary'</span><span class="p">,</span>
</span><span id="L-73"><a href="#L-73"><span class="linenos" data-line="73"></span></a>						<span class="s1">'layout'</span><span class="o">:</span> <span class="s1">'characters'</span><span class="p">,</span>
</span><span id="L-74"><a href="#L-74"><span class="linenos" data-line="74"></span></a>						<span class="s1">'characters'</span><span class="o">:</span><span class="p">[</span>
</span><span id="L-75"><a href="#L-75"><span class="linenos" data-line="75"></span></a>							<span class="p">{</span>
</span><span id="L-76"><a href="#L-76"><span class="linenos" data-line="76"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-77"><a href="#L-77"><span class="linenos" data-line="77"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-78"><a href="#L-78"><span class="linenos" data-line="78"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-79"><a href="#L-79"><span class="linenos" data-line="79"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{'</span><span class="p">,</span>
</span><span id="L-80"><a href="#L-80"><span class="linenos" data-line="80"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'Glossary|Title=|Short=|Long='</span><span class="p">,</span>
</span><span id="L-81"><a href="#L-81"><span class="linenos" data-line="81"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-82"><a href="#L-82"><span class="linenos" data-line="82"></span></a>									<span class="p">}</span>
</span><span id="L-83"><a href="#L-83"><span class="linenos" data-line="83"></span></a>								<span class="p">},</span>
</span><span id="L-84"><a href="#L-84"><span class="linenos" data-line="84"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Glossary Template'</span>
</span><span id="L-85"><a href="#L-85"><span class="linenos" data-line="85"></span></a>							<span class="p">},</span>
</span><span id="L-86"><a href="#L-86"><span class="linenos" data-line="86"></span></a>							<span class="p">{</span>
</span><span id="L-87"><a href="#L-87"><span class="linenos" data-line="87"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-88"><a href="#L-88"><span class="linenos" data-line="88"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-89"><a href="#L-89"><span class="linenos" data-line="89"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-90"><a href="#L-90"><span class="linenos" data-line="90"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'[['</span><span class="p">,</span>
</span><span id="L-91"><a href="#L-91"><span class="linenos" data-line="91"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'Category: Touch Glossary'</span><span class="p">,</span>
</span><span id="L-92"><a href="#L-92"><span class="linenos" data-line="92"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">']]'</span>
</span><span id="L-93"><a href="#L-93"><span class="linenos" data-line="93"></span></a>									<span class="p">}</span>
</span><span id="L-94"><a href="#L-94"><span class="linenos" data-line="94"></span></a>								<span class="p">},</span>
</span><span id="L-95"><a href="#L-95"><span class="linenos" data-line="95"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Glossary Category'</span>
</span><span id="L-96"><a href="#L-96"><span class="linenos" data-line="96"></span></a>							<span class="p">}</span>
</span><span id="L-97"><a href="#L-97"><span class="linenos" data-line="97"></span></a>						<span class="p">]</span>
</span><span id="L-98"><a href="#L-98"><span class="linenos" data-line="98"></span></a>					<span class="p">},</span>
</span><span id="L-99"><a href="#L-99"><span class="linenos" data-line="99"></span></a>					<span class="s1">'section-operators'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-100"><a href="#L-100"><span class="linenos" data-line="100"></span></a>						<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Operator Pages'</span><span class="p">,</span>
</span><span id="L-101"><a href="#L-101"><span class="linenos" data-line="101"></span></a>						<span class="s1">'layout'</span><span class="o">:</span> <span class="s1">'characters'</span><span class="p">,</span>
</span><span id="L-102"><a href="#L-102"><span class="linenos" data-line="102"></span></a>						<span class="s1">'characters'</span><span class="o">:</span><span class="p">[</span>
</span><span id="L-103"><a href="#L-103"><span class="linenos" data-line="103"></span></a>							<span class="p">{</span>
</span><span id="L-104"><a href="#L-104"><span class="linenos" data-line="104"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-105"><a href="#L-105"><span class="linenos" data-line="105"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-106"><a href="#L-106"><span class="linenos" data-line="106"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-107"><a href="#L-107"><span class="linenos" data-line="107"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{Summary'</span><span class="p">,</span>
</span><span id="L-108"><a href="#L-108"><span class="linenos" data-line="108"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|opLabel=|opType=|opClass=|opFilter=|opLicense=|opCategory=|os=|hardware=|short=|long='</span><span class="p">,</span>
</span><span id="L-109"><a href="#L-109"><span class="linenos" data-line="109"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-110"><a href="#L-110"><span class="linenos" data-line="110"></span></a>									<span class="p">}</span>
</span><span id="L-111"><a href="#L-111"><span class="linenos" data-line="111"></span></a>								<span class="p">},</span>
</span><span id="L-112"><a href="#L-112"><span class="linenos" data-line="112"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Operator Summary'</span>
</span><span id="L-113"><a href="#L-113"><span class="linenos" data-line="113"></span></a>							<span class="p">},</span>
</span><span id="L-114"><a href="#L-114"><span class="linenos" data-line="114"></span></a>							<span class="p">{</span>
</span><span id="L-115"><a href="#L-115"><span class="linenos" data-line="115"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-116"><a href="#L-116"><span class="linenos" data-line="116"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-117"><a href="#L-117"><span class="linenos" data-line="117"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-118"><a href="#L-118"><span class="linenos" data-line="118"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{ParameterPage'</span><span class="p">,</span>
</span><span id="L-119"><a href="#L-119"><span class="linenos" data-line="119"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|pageName=|pageSummary=|items='</span><span class="p">,</span>
</span><span id="L-120"><a href="#L-120"><span class="linenos" data-line="120"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-121"><a href="#L-121"><span class="linenos" data-line="121"></span></a>									<span class="p">}</span>
</span><span id="L-122"><a href="#L-122"><span class="linenos" data-line="122"></span></a>								<span class="p">},</span>
</span><span id="L-123"><a href="#L-123"><span class="linenos" data-line="123"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Parameter Page'</span>
</span><span id="L-124"><a href="#L-124"><span class="linenos" data-line="124"></span></a>							<span class="p">},</span>
</span><span id="L-125"><a href="#L-125"><span class="linenos" data-line="125"></span></a>							<span class="p">{</span>
</span><span id="L-126"><a href="#L-126"><span class="linenos" data-line="126"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-127"><a href="#L-127"><span class="linenos" data-line="127"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-128"><a href="#L-128"><span class="linenos" data-line="128"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-129"><a href="#L-129"><span class="linenos" data-line="129"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{ParameterSubPage'</span><span class="p">,</span>
</span><span id="L-130"><a href="#L-130"><span class="linenos" data-line="130"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|pageName=|pageSummary=|items='</span><span class="p">,</span>
</span><span id="L-131"><a href="#L-131"><span class="linenos" data-line="131"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-132"><a href="#L-132"><span class="linenos" data-line="132"></span></a>									<span class="p">}</span>
</span><span id="L-133"><a href="#L-133"><span class="linenos" data-line="133"></span></a>								<span class="p">},</span>
</span><span id="L-134"><a href="#L-134"><span class="linenos" data-line="134"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Parameter Sub Page'</span>
</span><span id="L-135"><a href="#L-135"><span class="linenos" data-line="135"></span></a>							<span class="p">},</span>
</span><span id="L-136"><a href="#L-136"><span class="linenos" data-line="136"></span></a>							<span class="p">{</span>
</span><span id="L-137"><a href="#L-137"><span class="linenos" data-line="137"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-138"><a href="#L-138"><span class="linenos" data-line="138"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-139"><a href="#L-139"><span class="linenos" data-line="139"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-140"><a href="#L-140"><span class="linenos" data-line="140"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{OPSection'</span><span class="p">,</span>
</span><span id="L-141"><a href="#L-141"><span class="linenos" data-line="141"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|sectionName=|sectionSummary=|items='</span><span class="p">,</span>
</span><span id="L-142"><a href="#L-142"><span class="linenos" data-line="142"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-143"><a href="#L-143"><span class="linenos" data-line="143"></span></a>									<span class="p">}</span>
</span><span id="L-144"><a href="#L-144"><span class="linenos" data-line="144"></span></a>								<span class="p">},</span>
</span><span id="L-145"><a href="#L-145"><span class="linenos" data-line="145"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Operator Section'</span>
</span><span id="L-146"><a href="#L-146"><span class="linenos" data-line="146"></span></a>							<span class="p">},</span>
</span><span id="L-147"><a href="#L-147"><span class="linenos" data-line="147"></span></a>							<span class="p">{</span>
</span><span id="L-148"><a href="#L-148"><span class="linenos" data-line="148"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-149"><a href="#L-149"><span class="linenos" data-line="149"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-150"><a href="#L-150"><span class="linenos" data-line="150"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-151"><a href="#L-151"><span class="linenos" data-line="151"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{OPSubSection'</span><span class="p">,</span>
</span><span id="L-152"><a href="#L-152"><span class="linenos" data-line="152"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|sectionName=|sectionSummary='</span><span class="p">,</span>
</span><span id="L-153"><a href="#L-153"><span class="linenos" data-line="153"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-154"><a href="#L-154"><span class="linenos" data-line="154"></span></a>									<span class="p">}</span>
</span><span id="L-155"><a href="#L-155"><span class="linenos" data-line="155"></span></a>								<span class="p">},</span>
</span><span id="L-156"><a href="#L-156"><span class="linenos" data-line="156"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Operator Sub Section'</span>
</span><span id="L-157"><a href="#L-157"><span class="linenos" data-line="157"></span></a>							<span class="p">},</span>
</span><span id="L-158"><a href="#L-158"><span class="linenos" data-line="158"></span></a>							<span class="p">{</span>
</span><span id="L-159"><a href="#L-159"><span class="linenos" data-line="159"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-160"><a href="#L-160"><span class="linenos" data-line="160"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-161"><a href="#L-161"><span class="linenos" data-line="161"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-162"><a href="#L-162"><span class="linenos" data-line="162"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{InfoCHOPChannels'</span><span class="p">,</span>
</span><span id="L-163"><a href="#L-163"><span class="linenos" data-line="163"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|opLabel=|infoChannels='</span><span class="p">,</span>
</span><span id="L-164"><a href="#L-164"><span class="linenos" data-line="164"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-165"><a href="#L-165"><span class="linenos" data-line="165"></span></a>									<span class="p">}</span>
</span><span id="L-166"><a href="#L-166"><span class="linenos" data-line="166"></span></a>								<span class="p">},</span>
</span><span id="L-167"><a href="#L-167"><span class="linenos" data-line="167"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Operator Info <span class="mw-lingo-term" data-lingo-term-id="8b9d2cce2836537aabe6f2e0dd5da293">CHOP</span> Section'</span>
</span><span id="L-168"><a href="#L-168"><span class="linenos" data-line="168"></span></a>							<span class="p">},</span>
</span><span id="L-169"><a href="#L-169"><span class="linenos" data-line="169"></span></a>							<span class="p">{</span>
</span><span id="L-170"><a href="#L-170"><span class="linenos" data-line="170"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-171"><a href="#L-171"><span class="linenos" data-line="171"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-172"><a href="#L-172"><span class="linenos" data-line="172"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-173"><a href="#L-173"><span class="linenos" data-line="173"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{InfoChannel'</span><span class="p">,</span>
</span><span id="L-174"><a href="#L-174"><span class="linenos" data-line="174"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|chanName=|chanSummary='</span><span class="p">,</span>
</span><span id="L-175"><a href="#L-175"><span class="linenos" data-line="175"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-176"><a href="#L-176"><span class="linenos" data-line="176"></span></a>									<span class="p">}</span>
</span><span id="L-177"><a href="#L-177"><span class="linenos" data-line="177"></span></a>								<span class="p">},</span>
</span><span id="L-178"><a href="#L-178"><span class="linenos" data-line="178"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Info <span class="mw-lingo-term" data-lingo-term-id="8b9d2cce2836537aabe6f2e0dd5da293">CHOP</span> <span class="mw-lingo-term" data-lingo-term-id="781dc97dc62331eec3ea9ec4373a3ca8">Channel</span>'</span>
</span><span id="L-179"><a href="#L-179"><span class="linenos" data-line="179"></span></a>							<span class="p">}</span>
</span><span id="L-180"><a href="#L-180"><span class="linenos" data-line="180"></span></a>						<span class="p">]</span>
</span><span id="L-181"><a href="#L-181"><span class="linenos" data-line="181"></span></a>					<span class="p">},</span>
</span><span id="L-182"><a href="#L-182"><span class="linenos" data-line="182"></span></a>					<span class="s1">'section-oppars'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-183"><a href="#L-183"><span class="linenos" data-line="183"></span></a>						<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Operator Parameters'</span><span class="p">,</span>
</span><span id="L-184"><a href="#L-184"><span class="linenos" data-line="184"></span></a>						<span class="s1">'layout'</span><span class="o">:</span> <span class="s1">'characters'</span><span class="p">,</span>
</span><span id="L-185"><a href="#L-185"><span class="linenos" data-line="185"></span></a>						<span class="s1">'characters'</span><span class="o">:</span><span class="p">[</span>
</span><span id="L-186"><a href="#L-186"><span class="linenos" data-line="186"></span></a>							<span class="p">{</span>
</span><span id="L-187"><a href="#L-187"><span class="linenos" data-line="187"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-188"><a href="#L-188"><span class="linenos" data-line="188"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-189"><a href="#L-189"><span class="linenos" data-line="189"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-190"><a href="#L-190"><span class="linenos" data-line="190"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{<span class="mw-lingo-term" data-lingo-term-id="83f499a540b1323009c200d6f8cc9396">Parameter</span>'</span><span class="p">,</span>
</span><span id="L-191"><a href="#L-191"><span class="linenos" data-line="191"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|opType=|parName=|parLabel=|parDefault=|parType=|parReadOnly=|parOrder=|parSummary=|parItems='</span><span class="p">,</span>
</span><span id="L-192"><a href="#L-192"><span class="linenos" data-line="192"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-193"><a href="#L-193"><span class="linenos" data-line="193"></span></a>									<span class="p">}</span>
</span><span id="L-194"><a href="#L-194"><span class="linenos" data-line="194"></span></a>								<span class="p">},</span>
</span><span id="L-195"><a href="#L-195"><span class="linenos" data-line="195"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'<span class="mw-lingo-term" data-lingo-term-id="83f499a540b1323009c200d6f8cc9396">Parameter</span>'</span>
</span><span id="L-196"><a href="#L-196"><span class="linenos" data-line="196"></span></a>							<span class="p">},</span>
</span><span id="L-197"><a href="#L-197"><span class="linenos" data-line="197"></span></a>							<span class="p">{</span>
</span><span id="L-198"><a href="#L-198"><span class="linenos" data-line="198"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-199"><a href="#L-199"><span class="linenos" data-line="199"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-200"><a href="#L-200"><span class="linenos" data-line="200"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-201"><a href="#L-201"><span class="linenos" data-line="201"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{ParameterItem'</span><span class="p">,</span>
</span><span id="L-202"><a href="#L-202"><span class="linenos" data-line="202"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'|opFamily=|parName=|itemName=|itemLabel=|itemDefault=|itemSummary='</span><span class="p">,</span>
</span><span id="L-203"><a href="#L-203"><span class="linenos" data-line="203"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-204"><a href="#L-204"><span class="linenos" data-line="204"></span></a>									<span class="p">}</span>
</span><span id="L-205"><a href="#L-205"><span class="linenos" data-line="205"></span></a>								<span class="p">},</span>
</span><span id="L-206"><a href="#L-206"><span class="linenos" data-line="206"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Parameter Item'</span>
</span><span id="L-207"><a href="#L-207"><span class="linenos" data-line="207"></span></a>							<span class="p">}</span>
</span><span id="L-208"><a href="#L-208"><span class="linenos" data-line="208"></span></a>						<span class="p">]</span>
</span><span id="L-209"><a href="#L-209"><span class="linenos" data-line="209"></span></a>					<span class="p">},</span>
</span><span id="L-210"><a href="#L-210"><span class="linenos" data-line="210"></span></a>					<span class="s1">'section-class'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-211"><a href="#L-211"><span class="linenos" data-line="211"></span></a>						<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Python Classes'</span><span class="p">,</span>
</span><span id="L-212"><a href="#L-212"><span class="linenos" data-line="212"></span></a>						<span class="s1">'layout'</span><span class="o">:</span> <span class="s1">'characters'</span><span class="p">,</span>
</span><span id="L-213"><a href="#L-213"><span class="linenos" data-line="213"></span></a>						<span class="s1">'characters'</span><span class="o">:</span><span class="p">[</span>
</span><span id="L-214"><a href="#L-214"><span class="linenos" data-line="214"></span></a>							<span class="p">{</span>
</span><span id="L-215"><a href="#L-215"><span class="linenos" data-line="215"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-216"><a href="#L-216"><span class="linenos" data-line="216"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-217"><a href="#L-217"><span class="linenos" data-line="217"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-218"><a href="#L-218"><span class="linenos" data-line="218"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{'</span><span class="p">,</span>
</span><span id="L-219"><a href="#L-219"><span class="linenos" data-line="219"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'OPClassSummary|OPfamily=|OPtype=|OPlabel='</span><span class="p">,</span>
</span><span id="L-220"><a href="#L-220"><span class="linenos" data-line="220"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-221"><a href="#L-221"><span class="linenos" data-line="221"></span></a>									<span class="p">}</span>
</span><span id="L-222"><a href="#L-222"><span class="linenos" data-line="222"></span></a>								<span class="p">},</span>
</span><span id="L-223"><a href="#L-223"><span class="linenos" data-line="223"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'OPClassSummary'</span>
</span><span id="L-224"><a href="#L-224"><span class="linenos" data-line="224"></span></a>							<span class="p">},</span>
</span><span id="L-225"><a href="#L-225"><span class="linenos" data-line="225"></span></a>							<span class="p">{</span>
</span><span id="L-226"><a href="#L-226"><span class="linenos" data-line="226"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-227"><a href="#L-227"><span class="linenos" data-line="227"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-228"><a href="#L-228"><span class="linenos" data-line="228"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-229"><a href="#L-229"><span class="linenos" data-line="229"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{'</span><span class="p">,</span>
</span><span id="L-230"><a href="#L-230"><span class="linenos" data-line="230"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'TDClassSummary|label=|summary='</span><span class="p">,</span>
</span><span id="L-231"><a href="#L-231"><span class="linenos" data-line="231"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-232"><a href="#L-232"><span class="linenos" data-line="232"></span></a>									<span class="p">}</span>
</span><span id="L-233"><a href="#L-233"><span class="linenos" data-line="233"></span></a>								<span class="p">},</span>
</span><span id="L-234"><a href="#L-234"><span class="linenos" data-line="234"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'TDClassSummary'</span>
</span><span id="L-235"><a href="#L-235"><span class="linenos" data-line="235"></span></a>							<span class="p">},</span>
</span><span id="L-236"><a href="#L-236"><span class="linenos" data-line="236"></span></a>							<span class="p">{</span>
</span><span id="L-237"><a href="#L-237"><span class="linenos" data-line="237"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-238"><a href="#L-238"><span class="linenos" data-line="238"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-239"><a href="#L-239"><span class="linenos" data-line="239"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-240"><a href="#L-240"><span class="linenos" data-line="240"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{'</span><span class="p">,</span>
</span><span id="L-241"><a href="#L-241"><span class="linenos" data-line="241"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'ClassMemberSection|Sectionsummary=|items=|empty='</span><span class="p">,</span>
</span><span id="L-242"><a href="#L-242"><span class="linenos" data-line="242"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-243"><a href="#L-243"><span class="linenos" data-line="243"></span></a>									<span class="p">}</span>
</span><span id="L-244"><a href="#L-244"><span class="linenos" data-line="244"></span></a>								<span class="p">},</span>
</span><span id="L-245"><a href="#L-245"><span class="linenos" data-line="245"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'ClassMemberSection'</span>
</span><span id="L-246"><a href="#L-246"><span class="linenos" data-line="246"></span></a>							<span class="p">},</span>
</span><span id="L-247"><a href="#L-247"><span class="linenos" data-line="247"></span></a>							<span class="p">{</span>
</span><span id="L-248"><a href="#L-248"><span class="linenos" data-line="248"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-249"><a href="#L-249"><span class="linenos" data-line="249"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-250"><a href="#L-250"><span class="linenos" data-line="250"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-251"><a href="#L-251"><span class="linenos" data-line="251"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{'</span><span class="p">,</span>
</span><span id="L-252"><a href="#L-252"><span class="linenos" data-line="252"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'ClassMember|class=|name=|type=|set=|text=|deprecated='</span><span class="p">,</span>
</span><span id="L-253"><a href="#L-253"><span class="linenos" data-line="253"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-254"><a href="#L-254"><span class="linenos" data-line="254"></span></a>									<span class="p">}</span>
</span><span id="L-255"><a href="#L-255"><span class="linenos" data-line="255"></span></a>								<span class="p">},</span>
</span><span id="L-256"><a href="#L-256"><span class="linenos" data-line="256"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'ClassMember'</span>
</span><span id="L-257"><a href="#L-257"><span class="linenos" data-line="257"></span></a>							<span class="p">},</span>
</span><span id="L-258"><a href="#L-258"><span class="linenos" data-line="258"></span></a>							<span class="p">{</span>
</span><span id="L-259"><a href="#L-259"><span class="linenos" data-line="259"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-260"><a href="#L-260"><span class="linenos" data-line="260"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-261"><a href="#L-261"><span class="linenos" data-line="261"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-262"><a href="#L-262"><span class="linenos" data-line="262"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{'</span><span class="p">,</span>
</span><span id="L-263"><a href="#L-263"><span class="linenos" data-line="263"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'ClassMethodSection|SectionSummary=|items=|empty='</span><span class="p">,</span>
</span><span id="L-264"><a href="#L-264"><span class="linenos" data-line="264"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-265"><a href="#L-265"><span class="linenos" data-line="265"></span></a>									<span class="p">}</span>
</span><span id="L-266"><a href="#L-266"><span class="linenos" data-line="266"></span></a>								<span class="p">},</span>
</span><span id="L-267"><a href="#L-267"><span class="linenos" data-line="267"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'ClassMethodSection'</span>
</span><span id="L-268"><a href="#L-268"><span class="linenos" data-line="268"></span></a>							<span class="p">},</span>
</span><span id="L-269"><a href="#L-269"><span class="linenos" data-line="269"></span></a>							<span class="p">{</span>
</span><span id="L-270"><a href="#L-270"><span class="linenos" data-line="270"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-271"><a href="#L-271"><span class="linenos" data-line="271"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-272"><a href="#L-272"><span class="linenos" data-line="272"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-273"><a href="#L-273"><span class="linenos" data-line="273"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{'</span><span class="p">,</span>
</span><span id="L-274"><a href="#L-274"><span class="linenos" data-line="274"></span></a>										<span class="s1">'peri'</span><span class="o">:</span><span class="s1">'ClassMethod|class=|name=|call=|returns=|text=|deprecated='</span><span class="p">,</span>
</span><span id="L-275"><a href="#L-275"><span class="linenos" data-line="275"></span></a>										<span class="s1">'post'</span><span class="o">:</span><span class="s1">'}}'</span>
</span><span id="L-276"><a href="#L-276"><span class="linenos" data-line="276"></span></a>									<span class="p">}</span>
</span><span id="L-277"><a href="#L-277"><span class="linenos" data-line="277"></span></a>								<span class="p">},</span>
</span><span id="L-278"><a href="#L-278"><span class="linenos" data-line="278"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'ClassMethod'</span>
</span><span id="L-279"><a href="#L-279"><span class="linenos" data-line="279"></span></a>							<span class="p">},</span>
</span><span id="L-280"><a href="#L-280"><span class="linenos" data-line="280"></span></a>							<span class="p">{</span>
</span><span id="L-281"><a href="#L-281"><span class="linenos" data-line="281"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-282"><a href="#L-282"><span class="linenos" data-line="282"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-283"><a href="#L-283"><span class="linenos" data-line="283"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-284"><a href="#L-284"><span class="linenos" data-line="284"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{SubSection|title=|text=}}'</span>
</span><span id="L-285"><a href="#L-285"><span class="linenos" data-line="285"></span></a>									<span class="p">}</span>
</span><span id="L-286"><a href="#L-286"><span class="linenos" data-line="286"></span></a>								<span class="p">},</span>
</span><span id="L-287"><a href="#L-287"><span class="linenos" data-line="287"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Class SubSection'</span>
</span><span id="L-288"><a href="#L-288"><span class="linenos" data-line="288"></span></a>							<span class="p">},</span>
</span><span id="L-289"><a href="#L-289"><span class="linenos" data-line="289"></span></a>						<span class="p">]</span>
</span><span id="L-290"><a href="#L-290"><span class="linenos" data-line="290"></span></a>					<span class="p">},</span>
</span><span id="L-291"><a href="#L-291"><span class="linenos" data-line="291"></span></a>					<span class="s1">'section-page'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-292"><a href="#L-292"><span class="linenos" data-line="292"></span></a>						<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'General Page Elements'</span><span class="p">,</span>
</span><span id="L-293"><a href="#L-293"><span class="linenos" data-line="293"></span></a>						<span class="s1">'layout'</span><span class="o">:</span> <span class="s1">'characters'</span><span class="p">,</span>
</span><span id="L-294"><a href="#L-294"><span class="linenos" data-line="294"></span></a>						<span class="s1">'characters'</span><span class="o">:</span><span class="p">[</span>
</span><span id="L-295"><a href="#L-295"><span class="linenos" data-line="295"></span></a>							<span class="p">{</span>
</span><span id="L-296"><a href="#L-296"><span class="linenos" data-line="296"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-297"><a href="#L-297"><span class="linenos" data-line="297"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-298"><a href="#L-298"><span class="linenos" data-line="298"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-299"><a href="#L-299"><span class="linenos" data-line="299"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{History}}'</span>
</span><span id="L-300"><a href="#L-300"><span class="linenos" data-line="300"></span></a>									<span class="p">}</span>
</span><span id="L-301"><a href="#L-301"><span class="linenos" data-line="301"></span></a>								<span class="p">},</span>
</span><span id="L-302"><a href="#L-302"><span class="linenos" data-line="302"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'<span class="mw-lingo-term" data-lingo-term-id="c101058e7ea21bbbf2a5ac893088e90b">Tag</span> History'</span>
</span><span id="L-303"><a href="#L-303"><span class="linenos" data-line="303"></span></a>							<span class="p">},</span>
</span><span id="L-304"><a href="#L-304"><span class="linenos" data-line="304"></span></a>							<span class="p">{</span>
</span><span id="L-305"><a href="#L-305"><span class="linenos" data-line="305"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-306"><a href="#L-306"><span class="linenos" data-line="306"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-307"><a href="#L-307"><span class="linenos" data-line="307"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-308"><a href="#L-308"><span class="linenos" data-line="308"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{SOPNavBox|opFamily=<span class="mw-lingo-term" data-lingo-term-id="28a7e2d07553a70b039bb585895e0bf0">SOP</span>}}'</span>
</span><span id="L-309"><a href="#L-309"><span class="linenos" data-line="309"></span></a>									<span class="p">}</span>
</span><span id="L-310"><a href="#L-310"><span class="linenos" data-line="310"></span></a>								<span class="p">},</span>
</span><span id="L-311"><a href="#L-311"><span class="linenos" data-line="311"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Category Navigation Box'</span>
</span><span id="L-312"><a href="#L-312"><span class="linenos" data-line="312"></span></a>							<span class="p">},</span>
</span><span id="L-313"><a href="#L-313"><span class="linenos" data-line="313"></span></a>							<span class="p">{</span>
</span><span id="L-314"><a href="#L-314"><span class="linenos" data-line="314"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-315"><a href="#L-315"><span class="linenos" data-line="315"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-316"><a href="#L-316"><span class="linenos" data-line="316"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-317"><a href="#L-317"><span class="linenos" data-line="317"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{#invoke:Category|list|COMPs}}'</span>
</span><span id="L-318"><a href="#L-318"><span class="linenos" data-line="318"></span></a>									<span class="p">}</span>
</span><span id="L-319"><a href="#L-319"><span class="linenos" data-line="319"></span></a>								<span class="p">},</span>
</span><span id="L-320"><a href="#L-320"><span class="linenos" data-line="320"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Category List'</span>
</span><span id="L-321"><a href="#L-321"><span class="linenos" data-line="321"></span></a>							<span class="p">},</span>
</span><span id="L-322"><a href="#L-322"><span class="linenos" data-line="322"></span></a>							<span class="p">{</span>
</span><span id="L-323"><a href="#L-323"><span class="linenos" data-line="323"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-324"><a href="#L-324"><span class="linenos" data-line="324"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-325"><a href="#L-325"><span class="linenos" data-line="325"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-326"><a href="#L-326"><span class="linenos" data-line="326"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'{{lowercase}}'</span>
</span><span id="L-327"><a href="#L-327"><span class="linenos" data-line="327"></span></a>									<span class="p">}</span>
</span><span id="L-328"><a href="#L-328"><span class="linenos" data-line="328"></span></a>								<span class="p">},</span>
</span><span id="L-329"><a href="#L-329"><span class="linenos" data-line="329"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Force pagetitle to lowercase'</span>
</span><span id="L-330"><a href="#L-330"><span class="linenos" data-line="330"></span></a>							<span class="p">},</span>
</span><span id="L-331"><a href="#L-331"><span class="linenos" data-line="331"></span></a>							<span class="p">{</span>
</span><span id="L-332"><a href="#L-332"><span class="linenos" data-line="332"></span></a>								<span class="s1">'action'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-333"><a href="#L-333"><span class="linenos" data-line="333"></span></a>									<span class="s1">'type'</span><span class="o">:</span> <span class="s1">'encapsulate'</span><span class="p">,</span>
</span><span id="L-334"><a href="#L-334"><span class="linenos" data-line="334"></span></a>									<span class="s1">'options'</span><span class="o">:</span> <span class="p">{</span>
</span><span id="L-335"><a href="#L-335"><span class="linenos" data-line="335"></span></a>										<span class="s1">'pre'</span><span class="o">:</span> <span class="s1">'#REDIRECT [[:Experimental:{{FULLPAGENAME}}]]'</span>
</span><span id="L-336"><a href="#L-336"><span class="linenos" data-line="336"></span></a>									<span class="p">}</span>
</span><span id="L-337"><a href="#L-337"><span class="linenos" data-line="337"></span></a>								<span class="p">},</span>
</span><span id="L-338"><a href="#L-338"><span class="linenos" data-line="338"></span></a>								<span class="s1">'label'</span><span class="o">:</span> <span class="s1">'Redirect to Experimental'</span>
</span><span id="L-339"><a href="#L-339"><span class="linenos" data-line="339"></span></a>							<span class="p">}</span>
</span><span id="L-340"><a href="#L-340"><span class="linenos" data-line="340"></span></a>						<span class="p">]</span>
</span><span id="L-341"><a href="#L-341"><span class="linenos" data-line="341"></span></a>					<span class="p">},</span>
</span><span id="L-342"><a href="#L-342"><span class="linenos" data-line="342"></span></a>				<span class="p">}</span>
</span><span id="L-343"><a href="#L-343"><span class="linenos" data-line="343"></span></a>			<span class="p">}</span>
</span><span id="L-344"><a href="#L-344"><span class="linenos" data-line="344"></span></a>		<span class="p">}</span>
</span><span id="L-345"><a href="#L-345"><span class="linenos" data-line="345"></span></a>	<span class="p">}</span> <span class="p">);</span>
</span><span id="L-346"><a href="#L-346"><span class="linenos" data-line="346"></span></a><span class="p">};</span>
</span><span id="L-347"><a href="#L-347"><span class="linenos" data-line="347"></span></a>
</span><span id="L-348"><a href="#L-348"><span class="linenos" data-line="348"></span></a>
</span><span id="L-349"><a href="#L-349"><span class="linenos" data-line="349"></span></a><span class="cm">/* Check if view is in edit mode and that the required modules are available. Then, customize the toolbar … */</span>
</span><span id="L-350"><a href="#L-350"><span class="linenos" data-line="350"></span></a><span class="k">if</span> <span class="p">(</span> <span class="p">[</span> <span class="s1">'edit'</span><span class="p">,</span> <span class="s1">'submit'</span> <span class="p">].</span><span class="nx">indexOf</span><span class="p">(</span> <span class="nx">mw</span><span class="p">.</span><span class="nx">config</span><span class="p">.</span><span class="nx">get</span><span class="p">(</span> <span class="s1">'wgAction'</span> <span class="p">)</span> <span class="p">)</span> <span class="o">!==</span> <span class="o">-</span><span class="mf">1</span> <span class="p">)</span> <span class="p">{</span>
</span><span id="L-351"><a href="#L-351"><span class="linenos" data-line="351"></span></a>	<span class="nx">mw</span><span class="p">.</span><span class="nx">loader</span><span class="p">.</span><span class="nx">using</span><span class="p">(</span> <span class="s1">'user.options'</span> <span class="p">).</span><span class="nx">then</span><span class="p">(</span> <span class="kd">function</span> <span class="p">()</span> <span class="p">{</span>
</span><span id="L-352"><a href="#L-352"><span class="linenos" data-line="352"></span></a>		<span class="c1">// This can be the string "0" if the user disabled the preference ([[phab:T54542#555387]])</span>
</span><span id="L-353"><a href="#L-353"><span class="linenos" data-line="353"></span></a>		<span class="k">if</span> <span class="p">(</span> <span class="nx">mw</span><span class="p">.</span><span class="nx">user</span><span class="p">.</span><span class="nx">options</span><span class="p">.</span><span class="nx">get</span><span class="p">(</span> <span class="s1">'usebetatoolbar'</span> <span class="p">)</span> <span class="o">==</span> <span class="mf">1</span> <span class="p">)</span> <span class="p">{</span>
</span><span id="L-354"><a href="#L-354"><span class="linenos" data-line="354"></span></a>			<span class="nx">$</span><span class="p">.</span><span class="nx">when</span><span class="p">(</span>
</span><span id="L-355"><a href="#L-355"><span class="linenos" data-line="355"></span></a>				<span class="nx">mw</span><span class="p">.</span><span class="nx">loader</span><span class="p">.</span><span class="nx">using</span><span class="p">(</span> <span class="s1">'ext.wikiEditor'</span> <span class="p">),</span> <span class="nx">$</span><span class="p">.</span><span class="nx">ready</span>
</span><span id="L-356"><a href="#L-356"><span class="linenos" data-line="356"></span></a>			<span class="p">).</span><span class="nx">then</span><span class="p">(</span> <span class="nx">customizeToolbar</span> <span class="p">);</span>
</span><span id="L-357"><a href="#L-357"><span class="linenos" data-line="357"></span></a>		<span class="p">}</span>
</span><span id="L-358"><a href="#L-358"><span class="linenos" data-line="358"></span></a>	<span class="p">}</span> <span class="p">);</span>
</span><span id="L-359"><a href="#L-359"><span class="linenos" data-line="359"></span></a><span class="p">}</span>
</span><span id="L-360"><a href="#L-360"><span class="linenos" data-line="360"></span></a>
</span><span id="L-361"><a href="#L-361"><span class="linenos" data-line="361"></span></a><span class="c1">// Redirect anonymous users to login form.</span>
</span><span id="L-362"><a href="#L-362"><span class="linenos" data-line="362"></span></a><span class="cm">/*</span>
</span><span id="L-363"><a href="#L-363"><span class="linenos" data-line="363"></span></a><span class="cm">jQuery(document).ready(function() {</span>
</span><span id="L-364"><a href="#L-364"><span class="linenos" data-line="364"></span></a><span class="cm">  if (jQuery('#pt-anon_oauth_login').length) {</span>
</span><span id="L-365"><a href="#L-365"><span class="linenos" data-line="365"></span></a><span class="cm">   var titleUrl = findGetParameter('title');</span>
</span><span id="L-366"><a href="#L-366"><span class="linenos" data-line="366"></span></a><span class="cm">   if (titleUrl) {</span>
</span><span id="L-367"><a href="#L-367"><span class="linenos" data-line="367"></span></a><span class="cm">     var returnUrl = '/index.php?title=Special:OAuth2Client/redirect&amp;returnto=' + titleUrl;</span>
</span><span id="L-368"><a href="#L-368"><span class="linenos" data-line="368"></span></a><span class="cm">   }</span>
</span><span id="L-369"><a href="#L-369"><span class="linenos" data-line="369"></span></a><span class="cm">   else {</span>
</span><span id="L-370"><a href="#L-370"><span class="linenos" data-line="370"></span></a><span class="cm">     var returnUrl = '/index.php?title=Special:OAuth2Client/redirect&amp;returnto=Main+Page';</span>
</span><span id="L-371"><a href="#L-371"><span class="linenos" data-line="371"></span></a><span class="cm">   }</span>
</span><span id="L-372"><a href="#L-372"><span class="linenos" data-line="372"></span></a><span class="cm">   window.location.href = returnUrl;</span>
</span><span id="L-373"><a href="#L-373"><span class="linenos" data-line="373"></span></a><span class="cm">  }</span>
</span><span id="L-374"><a href="#L-374"><span class="linenos" data-line="374"></span></a><span class="cm">});</span>
</span><span id="L-375"><a href="#L-375"><span class="linenos" data-line="375"></span></a><span class="cm">*/</span>
</span></pre></div></div><div class="mw-lingo-tooltip" id="8b9d2cce2836537aabe6f2e0dd5da293"><div class="mw-lingo-definition navigation-not-searchable"><div class="mw-lingo-definition-text">
<p>An <a href="/Operator_Family" title="Operator Family">Operator Family</a> which operate on <a href="/Channel" title="Channel">Channels</a> (a sequence of numbers (<a href="/Sample" title="Sample">Samples</a>)) which are used for animation, audio, mathematics, simulation, logic, UI construction, and data streamed from/to devices and protocols.
</p>
</div></div>
</div><div class="mw-lingo-tooltip" id="781dc97dc62331eec3ea9ec4373a3ca8"><div class="mw-lingo-definition navigation-not-searchable"><div class="mw-lingo-definition-text">
<p>A <a href="/CHOP" title="CHOP">CHOP</a> outputs one or more channels, where a channel is simply a sequence of numbers (<a href="/Sample" title="Sample">Samples</a>), representing motion, audio, etc. Channels are passed between CHOPs in TouchDesigner networks. Channels can be <a href="/Export" title="Export">Exported</a> to <a href="/Parameter" title="Parameter">Parameters</a>.
</p>
</div></div>
</div><div class="mw-lingo-tooltip" id="83f499a540b1323009c200d6f8cc9396"><div class="mw-lingo-definition navigation-not-searchable"><div class="mw-lingo-definition-text">
<p>Every operator in TouchDesigner has a set of control Parameters that can be integer or floating point numbers, menus, binary toggles, text strings or operator <a href="/Network_Path" title="Network Path">paths</a>, which determine the output of the operator.
</p>
</div></div>
</div><div class="mw-lingo-tooltip" id="c101058e7ea21bbbf2a5ac893088e90b"><div class="mw-lingo-definition navigation-not-searchable"><div class="mw-lingo-definition-text">
<p>Each operator can have a set of text strings that are its "tags". You can set them and search for them within TouchDesigner.
</p>
</div></div>
</div><div class="mw-lingo-tooltip" id="28a7e2d07553a70b039bb585895e0bf0"><div class="mw-lingo-definition navigation-not-searchable"><div class="mw-lingo-definition-text">
<p>A <a href="/Operator_Family" title="Operator Family">Operator Family</a> that reads, creates and modifies 3D points, polygons, lines, particles, surfaces, spheres and meatballs. Particles and point clouds are now done primarily on the GPU using TOPs.
</p>
</div></div>
</div>
<!-- 
NewPP limit report
Cached time: 20250314093031
Cache expiry: 60
Reduced expiry: true
Complications: []
CPU time usage: 0.588 seconds
Real time usage: 1.767 seconds
Preprocessor visited node count: 2803/1000000
Post‐expand include size: 30720/2097152 bytes
Template argument size: 3681/2097152 bytes
Highest expansion depth: 7/100
Expensive parser function count: 0/100
Unstrip recursion depth: 0/20
Unstrip post‐expand size: 623/5000000 bytes
Lua time usage: 1.230/10 seconds
Lua virtual size: 9424896/209715200 bytes
Lua estimated memory usage: 0 bytes
-->
<!--
Transclusion expansion time report (%,ms,calls,template)
100.00% 1707.087      1 -total
 95.93% 1637.601      1 Template:SOPNavBox
 94.48% 1612.781    114 Template:CatList
  3.55%   60.620      1 Template:SubSection
  0.13%    2.282      1 Template:History
  0.12%    2.099      1 Template:Lowercase
-->
</div>
<div class="printfooter" data-nosnippet="">Retrieved from "<a dir="ltr" href="https://docs.derivative.ca/index.php?title=MediaWiki:Common.js&amp;oldid=28654">https://docs.derivative.ca/index.php?title=MediaWiki:Common.js&amp;oldid=28654</a>"</div></div>
		<div id="catlinks" class="catlinks" data-mw="interface"><div id="mw-normal-catlinks" class="mw-normal-catlinks"><a href="/Special:Categories" title="Special:Categories">Category</a>: <ul><li><a href="/index.php?title=Category:COMPs&amp;action=edit&amp;redlink=1" class="new" title="Category:COMPs (page does not exist)">COMPs</a></li></ul></div></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		

<nav id="p-personal" class="vector-menu mw-portlet mw-portlet-personal vector-user-menu-legacy" aria-labelledby="p-personal-label" role="navigation"  >
	<h3
		id="p-personal-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Personal tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="pt-login" class="mw-list-item"><a href="/index.php?title=Special:UserLogin&amp;returnto=MediaWiki%3ACommon.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o"><span>Log in</span></a></li></ul>
		
	</div>
</nav>

		<div id="left-navigation">
			

<nav id="p-namespaces" class="vector-menu mw-portlet mw-portlet-namespaces vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-namespaces-label" role="navigation"  >
	<h3
		id="p-namespaces-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Namespaces</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-nstab-mediawiki" class="selected mw-list-item"><a href="/MediaWiki:Common.js" title="View the system message [c]" accesskey="c"><span>Message</span></a></li><li id="ca-talk" class="new mw-list-item"><a href="/index.php?title=MediaWiki_talk:Common.js&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t"><span>Discussion</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-variants" class="vector-menu mw-portlet mw-portlet-variants emptyPortlet vector-menu-dropdown" aria-labelledby="p-variants-label" role="navigation"  >
	<input type="checkbox"
		id="p-variants-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-variants"
		class="vector-menu-checkbox"
		aria-labelledby="p-variants-label"
	/>
	<label
		id="p-variants-label"
		 aria-label="Change language variant"
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">English</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

		</div>
		<div id="right-navigation">
			

<nav id="p-views" class="vector-menu mw-portlet mw-portlet-views vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-views-label" role="navigation"  >
	<h3
		id="p-views-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Views</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-view" class="selected mw-list-item"><a href="/MediaWiki:Common.js"><span>Read</span></a></li><li id="ca-viewsource" class="mw-list-item"><a href="/index.php?title=MediaWiki:Common.js&amp;action=edit" title="This page is protected.&#10;You can view its source [e]" accesskey="e"><span>View source</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-cactions" class="vector-menu mw-portlet mw-portlet-cactions emptyPortlet vector-menu-dropdown" aria-labelledby="p-cactions-label" role="navigation"  title="More options" >
	<input type="checkbox"
		id="p-cactions-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-cactions"
		class="vector-menu-checkbox"
		aria-labelledby="p-cactions-label"
	/>
	<label
		id="p-cactions-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			
<div id="p-search" role="search" class="vector-search-box-vue  vector-search-box-show-thumbnail vector-search-box-auto-expand-width vector-search-box">
	<div>
			<h3 >
				<label for="searchInput">Search</label>
			</h3>
		<form action="/index.php" id="searchform"
			class="vector-search-box-form">
			<div id="simpleSearch"
				class="vector-search-box-inner"
				 data-search-loc="header-navigation">
				<input class="vector-search-box-input"
					 type="search" name="search" placeholder="Search Derivative" aria-label="Search Derivative" autocapitalize="sentences" title="Search Derivative [f]" accesskey="f" id="searchInput"
				>
				<input type="hidden" name="title" value="Special:Search">
				<input id="mw-searchButton"
					 class="searchButton mw-fallbackSearchButton" type="submit" name="fulltext" title="Search the pages for this text" value="Search">
				<input id="searchButton"
					 class="searchButton" type="submit" name="go" title="Go to a page with this exact name if it exists" value="Go">
			</div>
		</form>
	</div>
</div>

		</div>
	</div>
	

<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a class="mw-wiki-logo" href="/Main_Page"
			title="Visit the main page"></a>
	</div>
	

<nav id="p-TouchDesigner" class="vector-menu mw-portlet mw-portlet-TouchDesigner vector-menu-portal portal" aria-labelledby="p-TouchDesigner-label" role="navigation"  >
	<h3
		id="p-TouchDesigner-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">TouchDesigner</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-Main-Page" class="mw-list-item"><a href="/Main_Page"><span>Main Page</span></a></li><li id="n-Categories" class="mw-list-item"><a href="/Special:Categories"><span>Categories</span></a></li><li id="n-Learn-TouchDesigner" class="mw-list-item"><a href="/Learn_TouchDesigner"><span>Learn TouchDesigner</span></a></li><li id="n-Tutorials" class="mw-list-item"><a href="/Tutorials"><span>Tutorials</span></a></li><li id="n-Interoperability" class="mw-list-item"><a href="/Interoperability"><span>Interoperability</span></a></li><li id="n-Glossary" class="mw-list-item"><a href="/TouchDesigner_Glossary"><span>Glossary</span></a></li><li id="n-Operators" class="mw-list-item"><a href="/Operator"><span>Operators</span></a></li><li id="n-Python" class="mw-list-item"><a href="/Python"><span>Python</span></a></li><li id="n-Python-Class-Reference" class="mw-list-item"><a href="/TouchDesigner_Python_Classes"><span>Python Class Reference</span></a></li><li id="n-Palette" class="mw-list-item"><a href="/Category:Palette"><span>Palette</span></a></li><li id="n-FAQ" class="mw-list-item"><a href="/Frequently_Asked_Questions"><span>FAQ</span></a></li><li id="n-Recent-Doc-Edits" class="mw-list-item"><a href="/Special:RecentChanges"><span>Recent Doc Edits</span></a></li><li id="n-Release-Notes" class="mw-list-item"><a href="/Release_Notes"><span>Release Notes</span></a></li></ul>
		
	</div>
</nav>

	

<nav id="p-Downloads" class="vector-menu mw-portlet mw-portlet-Downloads vector-menu-portal portal" aria-labelledby="p-Downloads-label" role="navigation"  >
	<h3
		id="p-Downloads-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Downloads</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-TouchDesigner" class="mw-list-item"><a href="https://www.derivative.ca/download" rel="nofollow"><span>TouchDesigner</span></a></li><li id="n-Shared-Examples" class="mw-list-item"><a href="http://www.derivative.ca/Forum/viewforum.php?f=22" rel="nofollow"><span>Shared Examples</span></a></li></ul>
		
	</div>
</nav>


<nav id="p-tb" class="vector-menu mw-portlet mw-portlet-tb vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation"  >
	<h3
		id="p-tb-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere" class="mw-list-item"><a href="/Special:WhatLinksHere/MediaWiki:Common.js" title="A list of all wiki pages that link here [j]" accesskey="j"><span>What links here</span></a></li><li id="t-recentchangeslinked" class="mw-list-item"><a href="/Special:RecentChangesLinked/MediaWiki:Common.js" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k"><span>Related changes</span></a></li><li id="t-specialpages" class="mw-list-item"><a href="/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q"><span>Special pages</span></a></li><li id="t-print" class="mw-list-item"><a href="javascript:print();" rel="alternate" title="Printable version of this page [p]" accesskey="p"><span>Printable version</span></a></li><li id="t-permalink" class="mw-list-item"><a href="/index.php?title=MediaWiki:Common.js&amp;oldid=28654" title="Permanent link to this revision of this page"><span>Permanent link</span></a></li><li id="t-info" class="mw-list-item"><a href="/index.php?title=MediaWiki:Common.js&amp;action=info" title="More information about this page"><span>Page information</span></a></li><li id="t-cargopagevalueslink" class="mw-list-item"><a href="/index.php?title=MediaWiki:Common.js&amp;action=pagevalues" rel="cargo-pagevalues"><span>Page values</span></a></li></ul>
		
	</div>
</nav>

	
</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info">
	<li id="footer-info-lastmod"> This page was last edited on 6 April 2023, at 11:23.</li>
</ul>

	<ul id="footer-places">
	<li id="footer-places-privacy"><a href="/Derivative:Privacy_policy">Privacy policy</a></li>
	<li id="footer-places-about"><a href="/Derivative:About">About Derivative</a></li>
	<li id="footer-places-disclaimer"><a href="/Derivative:General_disclaimer">Disclaimers</a></li>
</ul>

	<ul id="footer-icons" class="noprint">
	<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/resources/assets/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/resources/assets/poweredby_mediawiki_132x47.png 1.5x, /resources/assets/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
</ul>

</footer>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.000","walltime":"0.002","ppvisitednodes":{"value":2,"limit":1000000},"postexpandincludesize":{"value":0,"limit":2097152},"templateargumentsize":{"value":0,"limit":2097152},"expansiondepth":{"value":1,"limit":100},"expensivefunctioncount":{"value":0,"limit":100},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":0,"limit":5000000},"timingprofile":["100.00%    0.000      1 -total"]},"cachereport":{"timestamp":"20250314093029","ttl":86400,"transientcontent":false}}});mw.config.set({"wgBackendResponseTime":2258});});</script>
</body>
<!-- Cached 20250314093031 -->
</html>