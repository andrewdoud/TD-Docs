<!DOCTYPE html>
<html class="client-nojs" lang="en-CA" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>Related changes - Derivative</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":false,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"bc56cd3ec71e0a8b08c1ccbb","wgCSPNonce":false,"wgCanonicalNamespace":"Special","wgCanonicalSpecialPageName":"Recentchangeslinked","wgNamespaceNumber":-1,"wgPageName":"Special:RecentChangesLinked/mediawiki.special.changeslist.legend.js","wgTitle":"RecentChangesLinked/mediawiki.special.changeslist.legend.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":false,"wgIsRedirect":false,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageContentLanguage":"en-ca","wgPageContentModel":"wikitext","wgRelevantPageName":"Mediawiki.special.changeslist.legend.js","wgRelevantArticleId":0,"wgIsProbablyEditable":false,
"wgRelevantPageIsProbablyEditable":false,"wgCargoDefaultQueryLimit":100,"wgCargoMapClusteringMinimum":80,"wgCargoMonthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"wgCargoMonthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"wgCargoWeekDays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"wgCargoWeekDaysShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"wgPageFormsTargetName":null,"wgPageFormsAutocompleteValues":[],"wgPageFormsAutocompleteOnAllChars":false,"wgPageFormsFieldProperties":[],"wgPageFormsCargoFields":[],"wgPageFormsDependentFields":[],"wgPageFormsCalendarValues":[],"wgPageFormsCalendarParams":[],"wgPageFormsCalendarHTML":null,"wgPageFormsGridValues":[],"wgPageFormsGridParams":[],"wgPageFormsContLangYes":null,"wgPageFormsContLangNo":null,"wgPageFormsContLangMonths":[],"wgPageFormsHeightForMinimizingInstances":800,"wgPageFormsShowOnSelect"
:[],"wgPageFormsScriptPath":"/extensions/PageForms","edgValues":[],"wgPageFormsEDSettings":null,"wgAmericanDates":false,"wgVector2022PreviewPages":[],"wgStructuredChangeFilters":[{"name":"userExpLevel","type":"string_options","fullCoverage":true,"filters":[{"name":"unregistered","label":"rcfilters-filter-user-experience-level-unregistered-label","description":"rcfilters-filter-user-experience-level-unregistered-description","cssClass":"mw-changeslist-user-unregistered","priority":-2,"subset":[],"conflicts":[],"defaultHighlightColor":null},{"name":"registered","label":"rcfilters-filter-user-experience-level-registered-label","description":"rcfilters-filter-user-experience-level-registered-description","cssClass":"mw-changeslist-user-registered","priority":-3,"subset":[{"group":"userExpLevel","filter":"newcomer"},{"group":"userExpLevel","filter":"learner"},{"group":"userExpLevel","filter":"experienced"}],"conflicts":[],"defaultHighlightColor":null},{"name":"newcomer","label":
"rcfilters-filter-user-experience-level-newcomer-label","description":"rcfilters-filter-user-experience-level-newcomer-description","cssClass":"mw-changeslist-user-newcomer","priority":-4,"subset":[],"conflicts":[],"defaultHighlightColor":null},{"name":"learner","label":"rcfilters-filter-user-experience-level-learner-label","description":"rcfilters-filter-user-experience-level-learner-description","cssClass":"mw-changeslist-user-learner","priority":-5,"subset":[],"conflicts":[],"defaultHighlightColor":null},{"name":"experienced","label":"rcfilters-filter-user-experience-level-experienced-label","description":"rcfilters-filter-user-experience-level-experienced-description","cssClass":"mw-changeslist-user-experienced","priority":-6,"subset":[],"conflicts":[],"defaultHighlightColor":null}],"priority":-2,"conflicts":[],"title":"rcfilters-filtergroup-user-experience-level","separator":";","default":""},{"name":"authorship","type":"send_unselected_if_any","fullCoverage":true,"filters":[{
"name":"hidemyself","label":"rcfilters-filter-editsbyself-label","description":"rcfilters-filter-editsbyself-description","cssClass":"mw-changeslist-self","priority":-2,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":false},{"name":"hidebyothers","label":"rcfilters-filter-editsbyother-label","description":"rcfilters-filter-editsbyother-description","cssClass":"mw-changeslist-others","priority":-3,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":false}],"priority":-3,"conflicts":[],"title":"rcfilters-filtergroup-authorship"},{"name":"automated","type":"send_unselected_if_any","fullCoverage":true,"filters":[{"name":"hidebots","label":"rcfilters-filter-bots-label","description":"rcfilters-filter-bots-description","cssClass":"mw-changeslist-bot","priority":-2,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":true},{"name":"hidehumans","label":"rcfilters-filter-humans-label","description":"rcfilters-filter-humans-description","cssClass":
"mw-changeslist-human","priority":-3,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":false}],"priority":-4,"conflicts":[],"title":"rcfilters-filtergroup-automated"},{"name":"significance","type":"send_unselected_if_any","fullCoverage":true,"filters":[{"name":"hideminor","label":"rcfilters-filter-minor-label","description":"rcfilters-filter-minor-description","cssClass":"mw-changeslist-minor","priority":-2,"subset":[],"conflicts":[{"group":"changeType","filter":"hidelog","globalDescription":"rcfilters-hideminor-conflicts-typeofchange-global","contextDescription":"rcfilters-hideminor-conflicts-typeofchange"},{"group":"changeType","filter":"hidenewpages","globalDescription":"rcfilters-hideminor-conflicts-typeofchange-global","contextDescription":"rcfilters-hideminor-conflicts-typeofchange"}],"defaultHighlightColor":null,"default":false},{"name":"hidemajor","label":"rcfilters-filter-major-label","description":"rcfilters-filter-major-description","cssClass":
"mw-changeslist-major","priority":-3,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":false}],"priority":-6,"conflicts":[],"title":"rcfilters-filtergroup-significance"},{"name":"lastRevision","type":"send_unselected_if_any","fullCoverage":true,"filters":[{"name":"hidelastrevision","label":"rcfilters-filter-lastrevision-label","description":"rcfilters-filter-lastrevision-description","cssClass":"mw-changeslist-last","priority":-2,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":false},{"name":"hidepreviousrevisions","label":"rcfilters-filter-previousrevision-label","description":"rcfilters-filter-previousrevision-description","cssClass":"mw-changeslist-previous","priority":-3,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":false}],"priority":-7,"conflicts":[],"title":"rcfilters-filtergroup-lastrevision"},{"name":"changeType","type":"send_unselected_if_any","fullCoverage":true,"filters":[{"name":"hidepageedits","label":
"rcfilters-filter-pageedits-label","description":"rcfilters-filter-pageedits-description","cssClass":"mw-changeslist-src-mw-edit","priority":-2,"subset":[],"conflicts":[],"defaultHighlightColor":null,"default":false},{"name":"hidenewpages","label":"rcfilters-filter-newpages-label","description":"rcfilters-filter-newpages-description","cssClass":"mw-changeslist-src-mw-new","priority":-3,"subset":[],"conflicts":[{"group":"significance","filter":"hideminor","globalDescription":"rcfilters-hideminor-conflicts-typeofchange-global","contextDescription":"rcfilters-typeofchange-conflicts-hideminor"}],"defaultHighlightColor":null,"default":false},{"name":"hidelog","label":"rcfilters-filter-logactions-label","description":"rcfilters-filter-logactions-description","cssClass":"mw-changeslist-src-mw-log","priority":-5,"subset":[],"conflicts":[{"group":"significance","filter":"hideminor","globalDescription":"rcfilters-hideminor-conflicts-typeofchange-global","contextDescription":
"rcfilters-typeofchange-conflicts-hideminor"}],"defaultHighlightColor":null,"default":false}],"priority":-8,"conflicts":[],"title":"rcfilters-filtergroup-changetype"}],"wgStructuredChangeFiltersMessages":{"rcfilters-filtergroup-user-experience-level":"User registration and experience","rcfilters-filter-user-experience-level-unregistered-label":"Unregistered","rcfilters-filter-user-experience-level-unregistered-description":"Editors who aren't logged-in.","rcfilters-filter-user-experience-level-registered-label":"Registered","rcfilters-filter-user-experience-level-registered-description":"Logged-in editors.","rcfilters-filter-user-experience-level-newcomer-label":"Newcomers","rcfilters-filter-user-experience-level-newcomer-description":"Registered editors who have fewer than 10 edits or 4 days of activity.","rcfilters-filter-user-experience-level-learner-label":"Learners","rcfilters-filter-user-experience-level-learner-description":
"Registered editors whose experience falls between \"Newcomers\" and \"Experienced users.\"","rcfilters-filter-user-experience-level-experienced-label":"Experienced users","rcfilters-filter-user-experience-level-experienced-description":"Registered editors with more than 500 edits and 30 days of activity.","rcfilters-filtergroup-authorship":"Contribution authorship","rcfilters-filter-editsbyself-label":"Changes by you","rcfilters-filter-editsbyself-description":"Your own contributions.","rcfilters-filter-editsbyother-label":"Changes by others","rcfilters-filter-editsbyother-description":"All changes except your own.","rcfilters-filtergroup-automated":"Automated contributions","rcfilters-filter-bots-label":"Bot","rcfilters-filter-bots-description":"Edits made by automated tools.","rcfilters-filter-humans-label":"Human (not bot)","rcfilters-filter-humans-description":"Edits made by human editors.","rcfilters-filtergroup-significance":"Significance","rcfilters-filter-minor-label":
"Minor edits","rcfilters-filter-minor-description":"Edits the author labeled as minor.","rcfilters-hideminor-conflicts-typeofchange-global":"The \"Minor edits\" filter conflicts with one or more Type of change filters, because certain types of change cannot be designated as \"minor\". The conflicting filters are marked in the Active filters area, above.","rcfilters-hideminor-conflicts-typeofchange":"Certain types of change cannot be designated as \"minor\", so this filter conflicts with the following Type of Change filters: $1","rcfilters-filter-major-label":"Non-minor edits","rcfilters-filter-major-description":"Edits not labeled as minor.","rcfilters-filtergroup-lastrevision":"Latest revisions","rcfilters-filter-lastrevision-label":"Latest revision","rcfilters-filter-lastrevision-description":"Only the most recent change to a page.","rcfilters-filter-previousrevision-label":"Not the latest revision","rcfilters-filter-previousrevision-description":
"All changes that are not the \"latest revision\".","rcfilters-filtergroup-changetype":"Type of change","rcfilters-filter-pageedits-label":"Page edits","rcfilters-filter-pageedits-description":"Edits to wiki content, discussions, category descriptions…","rcfilters-filter-newpages-label":"Page creations","rcfilters-filter-newpages-description":"Edits that make new pages.","rcfilters-typeofchange-conflicts-hideminor":"This Type of change filter conflicts with the \"Minor edits\" filter. Certain types of change cannot be designated as \"minor\".","rcfilters-filter-logactions-label":"Logged actions","rcfilters-filter-logactions-description":"Administrative actions, account creations, page deletions, uploads…"},"wgStructuredChangeFiltersCollapsedState":false,"StructuredChangeFiltersDisplayConfig":{"maxDays":90,"limitArray":[50,100,250,500],"limitDefault":50,"daysArray":[1,3,7,14,30],"daysDefault":7},"wgStructuredChangeFiltersSavedQueriesPreferenceName":"rcfilters-saved-queries",
"wgStructuredChangeFiltersLimitPreferenceName":"rcfilters-limit","wgStructuredChangeFiltersDaysPreferenceName":"rcdays","wgStructuredChangeFiltersCollapsedPreferenceName":"rcfilters-rc-collapsed"};RLSTATE={"site.styles":"ready","user.styles":"ready","user":"ready","user.options":"loading","mediawiki.helplink":"ready","mediawiki.interface.helpers.styles":"ready","mediawiki.special.changeslist.legend":"ready","mediawiki.special.changeslist":"ready","mediawiki.rcfilters.filters.base.styles":"ready","mediawiki.icon":"ready","mediawiki.special.changeslist.enhanced":"ready","skins.vector.styles.legacy":"ready","mediawiki.feedlink":"ready"};RLPAGEMODULES=["ext.UiTag","mediawiki.special.changeslist.legend.js","mediawiki.rcfilters.filters.ui","jquery.makeCollapsible","site","mediawiki.page.ready","skins.vector.legacy.js"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@12s5i",function($,jQuery,require,module){mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});});});</script>
<link rel="stylesheet" href="/load.php?lang=en-ca&amp;modules=mediawiki.feedlink%2Chelplink%2Cicon%7Cmediawiki.interface.helpers.styles%7Cmediawiki.rcfilters.filters.base.styles%7Cmediawiki.special.changeslist%7Cmediawiki.special.changeslist.enhanced%2Clegend%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/load.php?lang=en-ca&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/load.php?lang=en-ca&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.39.0"/>
<meta name="robots" content="noindex,nofollow"/>
<meta name="format-detection" content="telephone=no"/>
<meta name="twitter:card" content="summary_large_image"/>
<meta name="viewport" content="width=1000"/>
<link rel="icon" href="/favicon.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/opensearch_desc.php" title="Derivative (en-ca)"/>
<link rel="EditURI" type="application/rsd+xml" href="https://docs.derivative.ca/api.php?action=rsd"/>
<link rel="alternate" type="application/atom+xml" title="&quot;Special:RecentChangesLinked/mediawiki.special.changeslist.legend.js&quot; Atom feed" href="/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;target=mediawiki.special.changeslist.legend.js&amp;action=feedrecentchanges&amp;feedformat=atom"/>
<link rel="alternate" type="application/atom+xml" title="Derivative Atom feed" href="/index.php?title=Special:RecentChanges&amp;feed=atom"/>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-3123499-6"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-3123499-6');
</script>
<meta property="og:title" content="Special:RecentChangesLinked/mediawiki.special.changeslist.legend.js"/>
<meta property="og:site_name" content="Derivative"/>
<meta property="og:url" content="https://docs.derivative.ca/Special:RecentChangesLinked/mediawiki.special.changeslist.legend.js"/>
<meta property="og:image" content="https://docs.derivative.ca/resources/assets/logo.png"/>
<meta property="article:modified_time" content="2025-05-24T00:56:06Z"/>
<meta property="article:published_time" content="2025-05-24T00:56:06Z"/>
<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"Article","name":"Related changes - Derivative","headline":"Related changes - Derivative","mainEntityOfPage":"Related changes","identifier":"https:\/\/docs.derivative.ca\/Special:RecentChangesLinked\/mediawiki.special.changeslist.legend.js","url":"https:\/\/docs.derivative.ca\/Special:RecentChangesLinked\/mediawiki.special.changeslist.legend.js","dateModified":"2025-05-24T00:56:06Z","datePublished":"2025-05-24T00:56:06Z","image":{"@type":"ImageObject","url":"https:\/\/docs.derivative.ca\/resources\/assets\/logo.png"},"author":{"@type":"Organization","name":"Derivative","url":"https:\/\/docs.derivative.ca","logo":{"@type":"ImageObject","url":"https:\/\/docs.derivative.ca\/resources\/assets\/logo.png","caption":"Derivative"}},"publisher":{"@type":"Organization","name":"Derivative","url":"https:\/\/docs.derivative.ca","logo":{"@type":"ImageObject","url":"https:\/\/docs.derivative.ca\/resources\/assets\/logo.png","caption":"Derivative"}},"potentialAction":{"@type":"SearchAction","target":"https:\/\/docs.derivative.ca\/index.php?title=Special:Search&search={search_term}","query-input":"required name=search_term"}}</script>
</head>
<body class="mw-rcfilters-enabled mediawiki ltr sitedir-ltr mw-hide-empty-elt ns--1 ns-special mw-special-Recentchangeslinked page-Special_RecentChangesLinked_mediawiki_special_changeslist_legend_js rootpage-Special_RecentChangesLinked_mediawiki_special_changeslist_legend_js skin-vector action-view skin-vector-legacy vector-feature-language-in-header-enabled vector-feature-language-in-main-page-header-disabled vector-feature-language-alert-in-sidebar-disabled vector-feature-sticky-header-disabled vector-feature-sticky-header-edit-disabled vector-feature-table-of-contents-disabled vector-feature-visual-enhancement-next-disabled"><div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice"></div>
	<div class="mw-indicators">
	<div id="mw-indicator-mw-helplink" class="mw-indicator"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/Help:Related_changes" target="_blank" class="mw-helplink">Help</a></div>
	</div>
	<h1 id="firstHeading" class="firstHeading mw-first-heading">Related changes</h1>
	<div id="bodyContent" class="vector-body">
		
		<div id="contentSub">← <a href="/index.php?title=Mediawiki.special.changeslist.legend.js&amp;action=edit&amp;redlink=1" class="new" title="Mediawiki.special.changeslist.legend.js (page does not exist)">Mediawiki.special.changeslist.legend.js</a></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" class="mw-body-content"><div class="mw-specialpage-summary">
<p>Enter a page name to see changes on pages linked to or from that page. (To see members of a category, enter Category:Name of category). Changes to pages on <a href="/Special:Watchlist" title="Special:Watchlist">your Watchlist</a> are in <strong>bold</strong>.
</p>
</div><div class="mw-rcfilters-head"><div class="mw-rcfilters-container"></div><fieldset class="rcoptions cloptions">
<legend>Recent changes options</legend>
<span class="rclinks">Show last <a href="/index.php?title=Special:RecentChangesLinked&amp;limit=50&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;limit&quot;:50}" data-keys="limit"><strong>50</strong></a> | <a href="/index.php?title=Special:RecentChangesLinked&amp;limit=100&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;limit&quot;:100}" data-keys="limit">100</a> | <a href="/index.php?title=Special:RecentChangesLinked&amp;limit=250&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;limit&quot;:250}" data-keys="limit">250</a> | <a href="/index.php?title=Special:RecentChangesLinked&amp;limit=500&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;limit&quot;:500}" data-keys="limit">500</a> changes in last <a href="/index.php?title=Special:RecentChangesLinked&amp;days=1&amp;from=&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;days&quot;:1,&quot;from&quot;:&quot;&quot;}" data-keys="days,from">1</a> | <a href="/index.php?title=Special:RecentChangesLinked&amp;days=3&amp;from=&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;days&quot;:3,&quot;from&quot;:&quot;&quot;}" data-keys="days,from">3</a> | <a href="/index.php?title=Special:RecentChangesLinked&amp;days=7&amp;from=&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;days&quot;:7,&quot;from&quot;:&quot;&quot;}" data-keys="days,from"><strong>7</strong></a> | <a href="/index.php?title=Special:RecentChangesLinked&amp;days=14&amp;from=&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;days&quot;:14,&quot;from&quot;:&quot;&quot;}" data-keys="days,from">14</a> | <a href="/index.php?title=Special:RecentChangesLinked&amp;days=30&amp;from=&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;days&quot;:30,&quot;from&quot;:&quot;&quot;}" data-keys="days,from">30</a> days</span><br /><span class="rcshowhide"><span class="rcshowhideliu rcshowhideoption clshowhideoption" data-filter-name="hideliu" data-feature-in-structured-ui="1"><a href="/index.php?title=Special:RecentChangesLinked&amp;hideliu=1&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;hideliu&quot;:1}" data-keys="hideliu">Hide</a> registered users</span> | <span class="rcshowhideanons rcshowhideoption clshowhideoption" data-filter-name="hideanons" data-feature-in-structured-ui="1"><a href="/index.php?title=Special:RecentChangesLinked&amp;hideanons=1&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;hideanons&quot;:1}" data-keys="hideanons">Hide</a> anonymous users</span> | <span class="rcshowhidemine rcshowhideoption clshowhideoption" data-filter-name="hidemyself" data-feature-in-structured-ui="1"><a href="/index.php?title=Special:RecentChangesLinked&amp;hidemyself=1&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;hidemyself&quot;:1}" data-keys="hidemyself">Hide</a> my edits</span> | <span class="rcshowhidebots rcshowhideoption clshowhideoption" data-filter-name="hidebots" data-feature-in-structured-ui="1"><a href="/index.php?title=Special:RecentChangesLinked&amp;hidebots=0&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;hidebots&quot;:0}" data-keys="hidebots">Show</a> bots</span> | <span class="rcshowhideminor rcshowhideoption clshowhideoption" data-filter-name="hideminor" data-feature-in-structured-ui="1"><a href="/index.php?title=Special:RecentChangesLinked&amp;hideminor=1&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;hideminor&quot;:1}" data-keys="hideminor">Hide</a> minor edits</span></span><br /><span class="rclistfrom"><a href="/index.php?title=Special:RecentChangesLinked&amp;from=20250524005606&amp;fromFormatted=19%3A56%2C+23+May+2025&amp;target=mediawiki.special.changeslist.legend.js" title="Special:RecentChangesLinked" data-params="{&quot;from&quot;:&quot;20250524005606&quot;,&quot;fromFormatted&quot;:&quot;19:56, 23 May 2025&quot;}" data-keys="from,fromFormatted">Show new changes starting from 19:56, 23 May 2025</a></span>
<hr />
<form action="/index.php"><table class="mw-recentchanges-table"><tr class="namespaceForm"><td class="mw-label mw-namespace-label"><label for="namespace">Namespace:</label></td><td class="mw-input"><select id="namespace" name="namespace">
<option value="" selected="">all</option>
<option value="0">(Main)</option>
<option value="1">Talk</option>
<option value="2">User</option>
<option value="3">User talk</option>
<option value="4">Derivative</option>
<option value="5">Derivative talk</option>
<option value="6">File</option>
<option value="7">File talk</option>
<option value="8">MediaWiki</option>
<option value="9">MediaWiki talk</option>
<option value="10">Template</option>
<option value="11">Template talk</option>
<option value="12">Help</option>
<option value="13">Help talk</option>
<option value="14">Category</option>
<option value="15">Category talk</option>
<option value="20">Experimental</option>
<option value="21">Experimental Talk</option>
<option value="106">Form</option>
<option value="107">Form talk</option>
<option value="274">Widget</option>
<option value="275">Widget talk</option>
<option value="828">Module</option>
<option value="829">Module talk</option>
<option value="2300">Gadget</option>
<option value="2301">Gadget talk</option>
<option value="2302">Gadget definition</option>
<option value="2303">Gadget definition talk</option>
</select> <span class="mw-input-with-label"><input name="invert" type="checkbox" value="1" id="nsinvert" title="Check this box to hide changes to pages within the selected namespace (and the associated namespace if checked)" /> <label for="nsinvert" title="Check this box to hide changes to pages within the selected namespace (and the associated namespace if checked)">Invert selection</label></span> <span class="mw-input-with-label"><input name="associated" type="checkbox" value="1" id="nsassociated" title="Check this box to also include the talk or subject namespace associated with the selected namespace" /> <label for="nsassociated" title="Check this box to also include the talk or subject namespace associated with the selected namespace">Associated namespace</label></span></td></tr><tr class="tagfilterForm"><td class="mw-label mw-tagfilter-label"><label for="tagfilter"><a href="/Special:Tags" title="Special:Tags">Tag</a> filter:</label></td><td class="mw-input"><input name="tagfilter" size="20" value="" class="mw-tagfilter-input mw-ui-input mw-ui-input-inline" id="tagfilter" list="tagfilter-datalist" /><datalist id="tagfilter-datalist"><option value="2018.24410">2018.24410</option>
<option value="2018.25850">2018.25850</option>
<option value="2018.28070">2018.28070</option>
<option value="2019.14650">2019.14650</option>
<option value="2019.17500">2019.17500</option>
<option value="2019.20700">2019.20700</option>
<option value="2019.30350">2019.30350</option>
<option value="2019.33020">2019.33020</option>
<option value="2020.20000">2020.20000</option>
<option value="2020.22080">2020.22080</option>
<option value="2020.23060">2020.23060</option>
<option value="2020.23680">2020.23680</option>
<option value="2021.10000">2021.10000</option>
<option value="2021.15020">2021.15020</option>
<option value="2022.24140">2022.24140</option>
<option value="2022.26590">2022.26590</option>
<option value="2022.28040">2022.28040</option>
<option value="2022.31030">2022.31030</option>
<option value="2023.11280">2023.11280</option>
<option value="mw-blank">Blanking</option>
<option value="mw-manual-revert">Manual revert</option>
<option value="mw-new-redirect">New redirect</option>
<option value="mw-changed-redirect-target">Redirect target changed</option>
<option value="mw-removed-redirect">Removed redirect</option>
<option value="mw-replace">Replaced</option>
<option value="mw-reverted">Reverted</option>
<option value="mw-rollback">Rollback</option>
<option value="TestTag">TestTag</option>
<option value="mw-undo">Undo</option>
<option value="wikieditor">wikieditor (hidden tag)</option></datalist></td></tr><tr class="targetForm"><td class="mw-label mw-target-label">Page name:</td><td class="mw-input"><input name="target" size="40" value="mediawiki.special.changeslist.legend.js" /><input name="showlinkedto" type="checkbox" value="1" id="showlinkedto" /> <label for="showlinkedto">Show changes to pages linked to the given page instead</label> <input type="submit" value="Show"/></td></tr></table><input type="hidden" value="Special:RecentChangesLinked" name="title"/></form>
</fieldset>
</div><div class="mw-rcfilters-spinner"><div class="mw-rcfilters-spinner-bounce"></div></div><div class="mw-changeslist-empty">No changes during the given period match these criteria.</div>
<div class="printfooter" data-nosnippet="">Retrieved from "<a dir="ltr" href="https://docs.derivative.ca/Special:RecentChangesLinked/mediawiki.special.changeslist.legend.js">https://docs.derivative.ca/Special:RecentChangesLinked/mediawiki.special.changeslist.legend.js</a>"</div></div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		

<nav id="p-personal" class="vector-menu mw-portlet mw-portlet-personal vector-user-menu-legacy" aria-labelledby="p-personal-label" role="navigation"  >
	<h3
		id="p-personal-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Personal tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="pt-login" class="mw-list-item"><a href="/index.php?title=Special:UserLogin&amp;returnto=Special%3ARecentChangesLinked%2Fmediawiki.special.changeslist.legend.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o"><span>Log in</span></a></li></ul>
		
	</div>
</nav>

		<div id="left-navigation">
			

<nav id="p-namespaces" class="vector-menu mw-portlet mw-portlet-namespaces vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-namespaces-label" role="navigation"  >
	<h3
		id="p-namespaces-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Namespaces</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-nstab-main" class="selected mw-list-item"><a href="/index.php?title=Mediawiki.special.changeslist.legend.js&amp;action=edit&amp;redlink=1" title="View the content page (page does not exist) [c]" accesskey="c"><span>Page</span></a></li><li id="ca-talk" class="new mw-list-item"><a href="/index.php?title=Talk:Mediawiki.special.changeslist.legend.js&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t"><span>Discussion</span></a></li><li id="ca-Experimental" class="new mw-list-item"><a href="/index.php?title=Experimental:Mediawiki.special.changeslist.legend.js&amp;action=edit&amp;redlink=1" title=" (page does not exist)"><span>Experimental</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-variants" class="vector-menu mw-portlet mw-portlet-variants emptyPortlet vector-menu-dropdown" aria-labelledby="p-variants-label" role="navigation"  >
	<input type="checkbox"
		id="p-variants-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-variants"
		class="vector-menu-checkbox"
		aria-labelledby="p-variants-label"
	/>
	<label
		id="p-variants-label"
		 aria-label="Change language variant"
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Canadian English</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

		</div>
		<div id="right-navigation">
			

<nav id="p-views" class="vector-menu mw-portlet mw-portlet-views emptyPortlet vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-views-label" role="navigation"  >
	<h3
		id="p-views-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Views</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			

<nav id="p-cactions" class="vector-menu mw-portlet mw-portlet-cactions emptyPortlet vector-menu-dropdown" aria-labelledby="p-cactions-label" role="navigation"  title="More options" >
	<input type="checkbox"
		id="p-cactions-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-cactions"
		class="vector-menu-checkbox"
		aria-labelledby="p-cactions-label"
	/>
	<label
		id="p-cactions-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			
<div id="p-search" role="search" class="vector-search-box-vue  vector-search-box-show-thumbnail vector-search-box-auto-expand-width vector-search-box">
	<div>
			<h3 >
				<label for="searchInput">Search</label>
			</h3>
		<form action="/index.php" id="searchform"
			class="vector-search-box-form">
			<div id="simpleSearch"
				class="vector-search-box-inner"
				 data-search-loc="header-navigation">
				<input class="vector-search-box-input"
					 type="search" name="search" placeholder="Search Derivative" aria-label="Search Derivative" autocapitalize="sentences" title="Search Derivative [f]" accesskey="f" id="searchInput"
				>
				<input type="hidden" name="title" value="Special:Search">
				<input id="mw-searchButton"
					 class="searchButton mw-fallbackSearchButton" type="submit" name="fulltext" title="Search the pages for this text" value="Search">
				<input id="searchButton"
					 class="searchButton" type="submit" name="go" title="Go to a page with this exact name if it exists" value="Go">
			</div>
		</form>
	</div>
</div>

		</div>
	</div>
	

<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a class="mw-wiki-logo" href="/Main_Page"
			title="Visit the main page"></a>
	</div>
	

<nav id="p-TouchDesigner" class="vector-menu mw-portlet mw-portlet-TouchDesigner vector-menu-portal portal" aria-labelledby="p-TouchDesigner-label" role="navigation"  >
	<h3
		id="p-TouchDesigner-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">TouchDesigner</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-Main-Page" class="mw-list-item"><a href="/Main_Page"><span>Main Page</span></a></li><li id="n-Categories" class="mw-list-item"><a href="/Special:Categories"><span>Categories</span></a></li><li id="n-Learn-TouchDesigner" class="mw-list-item"><a href="/Learn_TouchDesigner"><span>Learn TouchDesigner</span></a></li><li id="n-Tutorials" class="mw-list-item"><a href="/Tutorials"><span>Tutorials</span></a></li><li id="n-Interoperability" class="mw-list-item"><a href="/Interoperability"><span>Interoperability</span></a></li><li id="n-Glossary" class="mw-list-item"><a href="/TouchDesigner_Glossary"><span>Glossary</span></a></li><li id="n-Operators" class="mw-list-item"><a href="/Operator"><span>Operators</span></a></li><li id="n-Python" class="mw-list-item"><a href="/Python"><span>Python</span></a></li><li id="n-Python-Class-Reference" class="mw-list-item"><a href="/TouchDesigner_Python_Classes"><span>Python Class Reference</span></a></li><li id="n-Palette" class="mw-list-item"><a href="/Category:Palette"><span>Palette</span></a></li><li id="n-FAQ" class="mw-list-item"><a href="/Frequently_Asked_Questions"><span>FAQ</span></a></li><li id="n-Recent-Doc-Edits" class="mw-list-item"><a href="/Special:RecentChanges"><span>Recent Doc Edits</span></a></li><li id="n-Release-Notes" class="mw-list-item"><a href="/Release_Notes"><span>Release Notes</span></a></li></ul>
		
	</div>
</nav>

	

<nav id="p-Downloads" class="vector-menu mw-portlet mw-portlet-Downloads vector-menu-portal portal" aria-labelledby="p-Downloads-label" role="navigation"  >
	<h3
		id="p-Downloads-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Downloads</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-TouchDesigner" class="mw-list-item"><a href="https://www.derivative.ca/download" rel="nofollow"><span>TouchDesigner</span></a></li><li id="n-Shared-Examples" class="mw-list-item"><a href="http://www.derivative.ca/Forum/viewforum.php?f=22" rel="nofollow"><span>Shared Examples</span></a></li></ul>
		
	</div>
</nav>


<nav id="p-tb" class="vector-menu mw-portlet mw-portlet-tb vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation"  >
	<h3
		id="p-tb-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="feedlinks" class="mw-list-item"><a href="/api.php?hidebots=1&amp;urlversion=1&amp;days=7&amp;limit=50&amp;target=mediawiki.special.changeslist.legend.js&amp;action=feedrecentchanges&amp;feedformat=atom" id="feed-atom" rel="alternate" type="application/atom+xml" class="feedlink" title="Atom feed for this page"><span>Atom</span></a></li><li id="t-specialpages" class="mw-list-item"><a href="/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q"><span>Special pages</span></a></li><li id="t-print" class="mw-list-item"><a href="javascript:print();" rel="alternate" title="Printable version of this page [p]" accesskey="p"><span>Printable version</span></a></li></ul>
		
	</div>
</nav>

	
</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info">
</ul>

	<ul id="footer-places">
	<li id="footer-places-privacy"><a href="/Derivative:Privacy_policy">Privacy policy</a></li>
	<li id="footer-places-about"><a href="/Derivative:About">About Derivative</a></li>
	<li id="footer-places-disclaimer"><a href="/Derivative:General_disclaimer">Disclaimers</a></li>
</ul>

	<ul id="footer-icons" class="noprint">
	<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/resources/assets/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/resources/assets/poweredby_mediawiki_132x47.png 1.5x, /resources/assets/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
</ul>

</footer>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.004","walltime":"0.002","ppvisitednodes":{"value":3,"limit":1000000},"postexpandincludesize":{"value":8,"limit":2097152},"templateargumentsize":{"value":0,"limit":2097152},"expansiondepth":{"value":2,"limit":100},"expensivefunctioncount":{"value":0,"limit":100},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":0,"limit":5000000},"timingprofile":["100.00%    0.000      1 -total"]},"cachereport":{"timestamp":"20250524005606","ttl":86400,"transientcontent":false}}});mw.config.set({"wgBackendResponseTime":302});});</script>
</body>
</html>